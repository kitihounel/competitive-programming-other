#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <algorithm>

using namespace std;

int main(void) {
	
	int cases;
	cin >> cases;
	while (cases-->0) {
		string line;	
		int N; cin >> N; 
		getline(cin,line);

		map<int,int> original_a;
		map<int,int> original_b;

		bool alicesTurn = true; // Alice starts

		vector<string> alice;
		for (int i=0; i<N; i++) {
			getline(cin,line);
			for (int j=0; j<N; j++) {
				original_a[line[j]-'0']++;
			}
			alice.push_back(line);
		}

		vector<string> bob;
		for (int i=0; i<N; i++) {
			getline(cin,line);
		for (int j=0; j<N; j++) {
				original_b[line[j]-'0']++;
			}
			bob.push_back(line);
		}

		// Alice's moves
		vector<int> alice_moves_row(N*N);
		vector<int> alice_moves_col(N*N);
		for (int i=0; i<N*N; i++) {
			cin >> alice_moves_row[i] >> alice_moves_col[i];
		}
		
		// Bob's moves
		vector<int> bob_moves_col(N*N);
		vector<int> bob_moves_row(N*N);
		for (int i=0; i<N*N; i++) {
			cin >> bob_moves_row[i] >> bob_moves_col[i];
		}

		int alice_ind=0,bob_ind=0;
		map<int,int> alice_life;
		alice_life[1] = original_a[1];
		alice_life[2] = original_a[2];
		alice_life[3] = original_a[3];
		alice_life[4] = original_a[4];
		int alice_total_life = 4+3+2+1;

		map<int,int> bob_life;
		bob_life[1] = original_b[1];
		bob_life[2] = original_b[2];
		bob_life[3] = original_b[3];
		bob_life[4] = original_b[4];
		int bob_total_life = 4+3+2+1;

		map<int,string> boat_name;
		boat_name[1] = "Pram";
		boat_name[2] = "Sail Boat";
		boat_name[3] = "Battle Ship";
		boat_name[4] = "Hangar Ship";		

		while (bob_total_life > 0 && alice_total_life > 0) {
			if (alicesTurn) {
				int move_col = alice_moves_col[alice_ind];
				int move_row = alice_moves_row[alice_ind];
				alice_ind++;
				move_col--;
				move_row--;

				if (bob[move_row][move_col] != '.') {
					int thing = bob[move_row][move_col]-'0';
					bob[move_row][move_col] = 'X';

					bob_life[thing]--;
					if (bob_life[thing] == 0) {
						cout << "Alice sank Bob's " << boat_name[original_b[thing]] << endl;
						alicesTurn = !alicesTurn;
					}
					bob_total_life--;
				}
			}
			else { 
				int move_col = bob_moves_col[bob_ind];
				int move_row = bob_moves_row[bob_ind];
				bob_ind++;
				move_col--;
				move_row--;

				if (alice[move_row][move_col] != '.') {
					int thing = alice[move_row][move_col]-'0';
					alice_life[thing]--;

					if (alice_life[thing] == 0) {
						cout << "Bob sank Alice's " << boat_name[original_a[thing]] << endl;
						alicesTurn = !alicesTurn;
					}
					alice_total_life--;
				}
			}

			alicesTurn = !alicesTurn;
		}

		if (bob_total_life == 0) {
			cout << "Alice" << endl;
		}
		else {
			cout << "Bob" << endl;
		}
	}
}