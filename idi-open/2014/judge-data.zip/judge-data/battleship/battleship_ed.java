import java.io.*;
import java.util.*;
import static java.lang.System.out;


class battleship_ed {
    static Scanner sc = new Scanner(new BufferedInputStream(System.in));

    public static void main(String[] __) {
        for (int i = 0, T = sc.nextInt(); i < T; ++i)
            solveOne();
    }

    static void solveOne() {
        int N = sc.nextInt();

        int[][] aliceGrid = readGrid(N),
                bobGrid = readGrid(N);

        int[] aliceShips = countShips(aliceGrid),
              bobShips = countShips(bobGrid);

        String[] aliceShipNames = nameShips(aliceShips),
                 bobShipNames = nameShips(bobShips);

        Queue<Integer> aliceMoves = readMoves(N),
                       bobMoves = readMoves(N);

        boolean isAlicesTurn = true;
        for (;;) {
            int targetId = isAlicesTurn ? 1 : 0;

            int[][] targetGrid = isAlicesTurn ? bobGrid : aliceGrid;
            int[] targetShips  = isAlicesTurn ? bobShips : aliceShips;
            String[] targetShipNames = isAlicesTurn ? bobShipNames : aliceShipNames;
            Queue<Integer> attackMoves = isAlicesTurn ? aliceMoves : bobMoves;

            String attackerName = isAlicesTurn ? "Alice" : "Bob",
                   targetName = isAlicesTurn ? "Bob" : "Alice";

            isAlicesTurn = !isAlicesTurn;

            int hit = targetGrid[attackMoves.poll()][attackMoves.poll()];
            if (hit != -1) {
                targetShips[hit]--;

                if (targetShips[hit] == 0) {
                    out.printf("%s sank %s's %s\n", attackerName, targetName,
                                                    targetShipNames[hit]);
                    isAlicesTurn = !isAlicesTurn; // new turn
                }

                boolean didWin = true;
                for (int c : targetShips)
                    if (c != 0)
                        didWin = false;

                if (didWin) {
                    out.println(attackerName);
                    return;
                }
            }
        }
    }

    static int[][] readGrid(int N) {
        int[][] res = new int[N][N];
        for (int i = 0; i < N; ++i) {
            String xs = sc.next();
            for (int j = 0; j < N; ++j)
                if (xs.charAt(j) == '.')
                    res[i][j] = -1;
                else
                    res[i][j] = xs.charAt(j) - '1';
        }
        return res;
    }

    static int[] countShips(int[][] grid) {
        int[] res = new int[4];
        for (int[] xs : grid)
            for (int x : xs)
                if (x != -1)
                    res[x]++;
        return res;
    }

    static Queue<Integer> readMoves(int N) {
        Queue<Integer> res = new ArrayDeque<>();
        for (int i = 0; i < 2*N*N; ++i)
            res.offer(sc.nextInt() - 1);
        return res;
    }

    static String[] nameShips(int[] shipCounts) {
        String[] length2Name = { "Pram", "Sail Boat", "Battle Ship", "Hangar Ship" };

        String[] res = new String[4];
        for (int i = 0; i < 4; ++i)
            res[i] = length2Name[shipCounts[i]-1];
        return res;
    }
}
