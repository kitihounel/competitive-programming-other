#include <iostream>
#include <vector>

using namespace std;
int boardA[10][10];
int boardB[10][10];

int main(){
	int T;
	cin >> T;
	while(T--){
		int N;
		cin >> N;
		int numA[4], numB[4];
		for(int i = 0; i < 4; ++i){
			numA[i] = 0;
			numB[i] = 0;
		}
		// Alice
		for(int i = 0; i < N; ++i){
			for(int j = 0; j < N; ++j){
				char tmp;
				cin >> tmp;
				boardA[i][j] = tmp;
				if(tmp != '.')
					++numA[(int)(tmp-'1')];
			}
		}
		// Bob
		for(int i = 0; i < N; ++i){
			for(int j = 0; j < N; ++j){
				char tmp;
				cin >> tmp;
				boardB[i][j] = tmp;
				if(tmp != '.')
					++numB[(int)(tmp-'1')];
			}
		}

		// Find names of boats
		string names[4] = {"Pram", "Sail Boat", "Battle Ship", "Hangar Ship"};
		string namesA[4], namesB[4];
		for(int i = 0; i < 4; ++i){
			namesA[i] = names[numA[i]-1];
			namesB[i] = names[numB[i]-1];
		}

		// Read moves
		vector<int> rowA, colA;
		for(int i = 0; i < N*N; ++i){
			int tmpRow, tmpCol;
			cin >> tmpRow >> tmpCol;
			rowA.push_back(tmpRow-1);
			colA.push_back(tmpCol-1);
		}
		vector<int> rowB, colB;
		for(int i = 0; i < N*N; ++i){
			int tmpRow, tmpCol;
			cin >> tmpRow >> tmpCol;
			rowB.push_back(tmpRow-1);
			colB.push_back(tmpCol-1);
		}

		// Play game
		bool playerA = true;
		int moveA = 0;
		int sunkA = 0;
		int moveB = 0;
		int sunkB = 0;
		while(true){
			if(sunkA == 4){
				cout << "Alice\n";
				break;
			}
			if(sunkB == 4){
				cout << "Bob\n";
				break;
			}
			if(playerA){
				int row = rowA[moveA];
				int col = colA[moveA];
				++moveA;
				playerA = false;
				if(boardB[row][col] != '.'){
					int typ = (int)(boardB[row][col]-'1');
					--numB[typ];
					if(numB[typ] == 0){
						cout << "Alice sank Bob's ";
						cout << namesB[typ] << endl;
						playerA = true;
						++sunkA;
					}
				}
			}
			if(!playerA){
				int row = rowB[moveB];
				int col = colB[moveB];
				++moveB;
				playerA = true;
				if(boardA[row][col] != '.'){
					int typ = (int)(boardA[row][col]-'1');
					--numA[typ];
					if(numA[typ] == 0){
						cout << "Bob sank Alice's ";
						cout << namesA[typ] << endl;
						playerA = false;
						++sunkB;
					}
				}
			}
		}
	}
}
