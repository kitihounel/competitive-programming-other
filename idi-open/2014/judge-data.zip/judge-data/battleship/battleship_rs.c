#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define MAX 10
char g[2][MAX][MAX+1];
int n;
int sz[2][4],left[2][4],bleft[2];
int mx[2][MAX*MAX],my[2][MAX*MAX];
char navn[2][6]={"Alice","Bob"};
char baat[4][12]={"Pram","Sail Boat","Battle Ship","Hangar Ship"};

void solve() {
	int i,j,p,L[2],x,y;
	char c;
	scanf("%d",&n);
	memset(sz,0,sizeof(sz));
	bleft[0]=bleft[1]=4;
	for(p=0;p<2;p++) {
		for(i=0;i<n;i++) scanf("%s",g[p][i]);
		for(i=0;i<n;i++) for(j=0;j<n;j++) if(isdigit(g[p][i][j])) sz[p][g[p][i][j]-'1']++;
	}
	memcpy(left,sz,sizeof(sz));
	for(p=0;p<2;p++) for(i=0;i<n*n;i++) scanf("%d %d",&mx[p][i],&my[p][i]);
	L[0]=L[1]=p=0;
	while(1) {
		x=mx[p][L[p]]-1;
		y=my[p][L[p]++]-1;
		c=g[p^1][x][y];
		if(c!='.') {
			j=c-'1';
			if(!--left[p^1][j]) {
				printf("%s sank %s's %s\n",navn[p],navn[p^1],baat[sz[p^1][j]-1]);
				if(!--bleft[p^1]) {
					puts(navn[p]);
					break;
				}
			} else p^=1;
		} else p^=1;
	}
}

int main() {
	int T;
	scanf("%d",&T);
	while(T--) solve();
	return 0;
}
