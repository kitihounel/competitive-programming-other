#include <iostream>
#include <string>
#include <cstring>

using namespace std;

string grids[2][10];
int ship_counts[2][4];
string players[2];
string ships[2][4];

int moves[2][100][2];

string ship_names[5];

void solve() {
  ship_names[1] = "Pram";
  ship_names[2] = "Sail Boat";
  ship_names[3] = "Battle Ship";
  ship_names[4] = "Hangar Ship";

  players[0] = "Alice";
  players[1] = "Bob";

  memset(ship_counts, 0, sizeof(ship_counts));
  int N; cin >> N;
  for (int player = 0; player < 2; ++player) {
    for (int i = 0; i < N; ++i) {
      cin >> grids[player][i];
      for (int j = 0; j < N; ++j) {
        if (grids[player][i][j] != '.') {
          ship_counts[player][grids[player][i][j] - '1']++;
        }
      }
    }
    for (int i = 0; i < 4; ++i) {
      ships[player][i] = ship_names[i+1];
      ship_counts[player][i] = i+1;
    }
  }
  for (int player = 0; player < 2; ++player) {
    for (int i = 0; i < N * N; ++i) {
      cin >> moves[player][i][0] >> moves[player][i][1];
      moves[player][i][0]--; moves[player][i][1]--;
    }
  }
  int player = 0;
  int move_counters[2] = {0, 0};
  while (true) {
    int other = 1 - player;
    int x = moves[player][move_counters[player]][0];
    int y = moves[player][move_counters[player]][1];
    move_counters[player]++;
    if (grids[other][x][y] == '.') {
      player = 1 - player;
      continue;
    } else {
      int hit = grids[other][x][y] - '1';
      if (--ship_counts[other][hit]) {
        player = 1 - player;
        continue;
      } else {
        cout << players[player] << " sank " << players[other] << "'s " << ships[other][hit] << endl;
        int won = 1;
        for (int i = 0; i < 4; ++i) {
          if (ship_counts[other][i]) won = 0;
        }
        if (won) {
          cout << players[player] << endl;
          break;
        } else {
          continue;
        }
      }
    }
  }
}

int main() {
  int TC; cin >> TC;
  while (TC--) {
    solve();
  }
}
