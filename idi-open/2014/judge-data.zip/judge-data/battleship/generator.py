from random import shuffle, randint

print 20

for c in xrange(20):
  N = randint(4,10)
  print N
  board1 = [['.'] * N for i in xrange(N)]
  board2 = [['.'] * N for i in xrange(N)]

  ships1 = ['1', '2', '3', '4']
  shuffle(ships1)
  ships2 = ['1', '2', '3', '4']
  shuffle(ships2)

  for i, s in enumerate(ships1):
    found = False
    while not found:
      x = randint(0, N)
      y = randint(0, N)
      for dx, dy in [(1, 0), (-1, 0), (0, 1), (0, -1)]:
        ok = True
        for j in xrange(i+1):
          nx = x + j * dx
          ny = y + j * dy
          if ny < 0 or ny >= N or nx < 0 or nx >= N or board1[nx][ny] != '.':
            ok = False
            break
        if ok:
          found = True
          for j in xrange(i+1):
            nx = x + j * dx
            ny = y + j * dy
            board1[nx][ny] = s
  
  for i, s in enumerate(ships2):
    found = False
    while not found:
      x = randint(0, N)
      y = randint(0, N)
      for dx, dy in [(1, 0), (-1, 0), (0, 1), (0, -1)]:
        ok = True
        for j in xrange(i+1):
          nx = x + j * dx
          ny = y + j * dy
          if ny < 0 or ny >= N or nx < 0 or nx >= N or board2[nx][ny] != '.':
            ok = False
            break
        if ok:
          found = True
          for j in xrange(i+1):
            nx = x + j * dx
            ny = y + j * dy
            board2[nx][ny] = s
  
  print "\n".join(["".join(line) for line in board1])
  print "\n".join(["".join(line) for line in board2])

  moves1 = [(a, b) for a in xrange(1, N+1) for b in xrange(1, N+1)]
  shuffle(moves1)
  for a, b in moves1:
    print a, b
  shuffle(moves1)
  for a, b in moves1:
    print a, b
