#include <iostream>

using namespace std;

int main(void) {
  int cases; cin >> cases;
  while (cases-->0) {
	int max_attempts,bottles; cin >> max_attempts >> bottles;
	int result=0;
	for (int i=0; i<bottles; i++) {
		int attempts; cin >> attempts;
		if (attempts>max_attempts)
			result++;
	}
	cout << result << endl;
  }
}
