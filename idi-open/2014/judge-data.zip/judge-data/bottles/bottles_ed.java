class bottles_ed {
    public static void main(String[] __) {
        java.util.Scanner sc = new java.util.Scanner(System.in);

        int cases = sc.nextInt();

	while (cases-->0) {
	    int E = sc.nextInt(),
		N = sc.nextInt();

	    int numEmpty = 0;
	    for (int i = 0; i < N; ++i)
		if (sc.nextInt() > E)
		    ++numEmpty;
	    System.out.println(numEmpty);
	}
    }
}
