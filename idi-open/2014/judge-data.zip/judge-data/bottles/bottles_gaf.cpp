#include <iostream>

using namespace std;

int main(){
	int T;
	cin >> T;
	while(T--){
		int E, N;
		cin >> E >> N;
		int tot = 0;
		for(int i = 0; i < N; ++i){
			int tmp;
			cin >> tmp;
			if(tmp > E)
				++tot;
		}
		cout << tot << endl;
	}
}

