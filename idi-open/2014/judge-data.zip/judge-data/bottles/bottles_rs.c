#include <stdio.h>

int main() {
  int cases;
  scanf("%d",&cases);
  while (cases--) {
	int E,N,r,a;
	scanf("%d %d",&E,&N);
	r=0;
	while(N--) {
		scanf("%d",&a);
		if(a>E) r++;
	}
	printf("%d\n",r);
  }
	return 0;
}
