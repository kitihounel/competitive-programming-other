import random

C = 10

print C

for i in xrange(C - 1):
	N = random.randint(1,10)
	E = random.randint(1,1000)

	print E,N
	for i in xrange(N):
		print random.randint(1,1000)

# One case where it's equal
N = random.randint(1,10)
E = random.randint(1,1000)

print E,N
for i in xrange(N):
	print E
