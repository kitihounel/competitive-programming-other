#include <algorithm>
#include <cmath>
#include <cstdio>
#include <queue>
#include <set>
#include <vector>

using namespace std;

typedef vector<int> vi;
typedef vector<vector<int>> vvi;
typedef vector<double> vd;
typedef queue<int> qi;

int I() { int n; scanf("%d", &n); return n; }

int N, M, K;
vvi sheepPos, barnPos, edges;
vd edgeLens;

void buildEdges() {
  set<double> edgeLenAccum;

  for (int i = 0; i < N; ++i) for (int j = 0; j < M; ++j) {
    vi sp = sheepPos[i],
       bp = barnPos[j];
    int dSquared = (sp[0]-bp[0])*(sp[0]-bp[0]) +
                   (sp[1]-bp[1])*(sp[1]-bp[1]);
    edges.push_back(vi { dSquared, i, j });
    edgeLenAccum.insert(dSquared);
  }

  sort(edges.begin(), edges.end());
  edgeLens = vd(edgeLenAccum.begin(), edgeLenAccum.end());
}

bool hasMatching(int thresholdEdgeLen) {
  int Max = N+M+2,
      src = Max-2,
      sink = Max-1;

  vvi R(Max, vi(Max, 0)),
      adjs(Max, vi());

  for (int i = 0; i < N; ++i) R[src][i] += 1;
  for (int i = 0; i < M; ++i) R[N+i][sink] += K;

  for (int i = 0; i < N*M && edges[i][0] <= thresholdEdgeLen; ++i)
    R[ edges[i][1] ][ N+edges[i][2] ] += 1;

  for (int i = 0; i < Max; ++i) for (int j = 0; j < Max; ++j)
    if (R[i][j] != 0) {
      adjs[i].push_back(j);
      adjs[j].push_back(i);
    }

  // Augment where we can up front. WTHN?
  for (int i = 0; i < N; ++i) for (int j = N; j < N+M; ++j) {
    int c = min(R[src][i], min(R[i][j], R[j][sink]));
    R[src][i]  -= c; R[i][src]  += c;
    R[i][j]    -= c; R[j][i]    += c;
    R[j][sink] -= c; R[sink][j] += c;
  }


  int p;
  for (;;) {
    qi Q;
    vi P(Max, -1);

    Q.push(src);
    P[src] = src;

    for (;;) {
      if (Q.empty()) goto OUT;

      int u = Q.front(); Q.pop();
      if (u == sink) {
        int f = 1<<30;
        for (; u != src; u = P[u]) f = min(f, R[ P[u] ][ u ]);
        for (u = sink; u != src; u = p) { p=P[u]; R[p][u]-=f; R[u][p]+=f; }
        break;
      }
      for (int v : adjs[u]) if (R[u][v] && P[v]==-1) { P[v]=u; Q.push(v); }
    }
  }

OUT:
  int res = 0;
  for (int i : adjs[src]) res += R[i][src];
  return res == N;
}

double findMinBottleneckLen() {
  int left = 0, right = edgeLens.size()-1;
  double ans = edgeLens[edgeLens.size()-1];

  while (left <= right) {
    int mid = (left + right) / 2;
    if (hasMatching(edgeLens[mid])) {
      ans = min(ans, edgeLens[mid]);
      right = mid - 1;
    } else
      left = mid + 1;
  }

  return sqrt(ans);
}

void solveOne() {
  N = I(); M = I(); K = I();

  sheepPos.clear();
  barnPos.clear();
  edges.clear();
  for (int i = 0; i < N; ++i) {
    vi xs; xs.push_back(I()); xs.push_back(I());
    sheepPos.push_back(xs);
  }

  for (int i = 0; i < M; ++i) {
    vi xs; xs.push_back(I()); xs.push_back(I());
    barnPos.push_back(xs);
  }

  buildEdges();

  printf("%.9f\n", findMinBottleneckLen());
}

int main() {
  int T = I();
  for (int t = 0; t < T; t++) {
    solveOne();
  }
  return 0;
}
