import java.util.*;
import java.io.*;
import static java.lang.System.out;
import static java.lang.Math.*;


public class browse_ed {
  static BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
  static StringTokenizer st = new StringTokenizer("");
  static String T() throws Exception {
    while (!st.hasMoreTokens()) {
      st = new StringTokenizer(stdin.readLine());
    }
    return st.nextToken();
  }
  static int I() throws Exception { return Integer.parseInt(T()); }

  public static void main(String[] __) throws Exception {
    for (int t = 0, T = I(); t < T; ++t) {
      N = I(); M = I(); K = I();
      readAndBuildEdges();
      out.printf("%.8f\n", findMinBottleneckLen());
    }
  }

  static int N, M, K;
  static int[][] edges;
  static Integer[] edgeLens;

  static int[][] R, adjs;
  static int[] seen;

  static double findMinBottleneckLen() {
    int left = 0, right = edgeLens.length-1;
    double ans = edgeLens[edgeLens.length-1];

    while (left <= right) {
      int mid = (left + right) / 2;
      if (hasMatching(edgeLens[mid])) {
        ans = min(ans, edgeLens[mid]);
        right = mid - 1;
      } else
        left = mid + 1;
    }

    return sqrt(ans);
  }

  static boolean hasMatching(int maxlen) {
    int Max = N+M+2,
        src = Max-2,
        sink = Max-1;

    R = new int[Max][Max];
    adjs = new int[Max][Max+1];

    for (int i = 0; i < N; ++i) R[src][i] += 1;
    for (int i = 0; i < M; ++i) R[N+i][sink] += K;
    for (int i = 0; i < edges.length && edges[i][2] <= maxlen; ++i)
      R[ edges[i][0] ][ N+edges[i][1] ] += 1;

    for (int i = 0; i < Max; ++i) for (int j = 0; j < Max; ++j)
      if (R[i][j] != 0) {
        adjs[ i ][ ++adjs[i][0] ] = j;
        adjs[ j ][ ++adjs[j][0] ] = i;
      }

    int res = 0;

    // Augment where we can up front. WTHN?
    for (int i = 0; i < N; ++i) for (int j = N; j < N+M; ++j) {
      int c = min(R[src][i], min(R[i][j], R[j][sink]));
      R[src][i]  -= c; R[i][src]  += c;
      R[i][j]    -= c; R[j][i]    += c;
      R[j][sink] -= c; R[sink][j] += c;
      res += c;
    }

    seen = new int[Max];
    for (int t = 1; ; ++t) {
      int f = dfsflow(src, sink, 1<<30, t);
      res += f;
      if (f == 0)
        return res == N;
    }
  }

  static int dfsflow(final int u, final int sink, final int inc, final int t) {
    if (seen[u] == t) return 0;
    if (u == sink) return inc;

    seen[u] = t;

    for (int i = 1; i <= adjs[u][0]; ++i) {
      int v = adjs[u][i];

      if (seen[v] != t && R[u][v] > 0) {
        int f = dfsflow(v, sink, min(inc, R[u][v]), t);

        if (f > 0) {
          R[u][v] -= f;
          R[v][u] += f;
          return f;
        }
      }
    }

    return 0;
  }

  static void readAndBuildEdges() throws Exception {
    int[][] sheep = new int[N][2],
            barn  = new int[M][2];

    for (int i = 0; i < N; ++i) { sheep[i][0] = I(); sheep[i][1] = I(); }
    for (int i = 0; i < M; ++i) { barn[ i][0] = I(); barn[ i][1] = I(); }

    edges = new int[N*M][3];
    List<Integer> allEdgeLens = new ArrayList<>();

    for (int i = 0; i < N; ++i) for (int j = 0; j < M; ++j) {
      int[] sp = sheep[i], bp = barn[j];

      int dSquared = (sp[0]-bp[0])*(sp[0]-bp[0]) +
                     (sp[1]-bp[1])*(sp[1]-bp[1]);

      edges[i*M+j] = new int[]{ i, j, dSquared };
      allEdgeLens.add(dSquared);
    }

    edgeLens = new TreeSet<>(allEdgeLens).toArray(new Integer[]{});
    Arrays.sort(edges, new Comparator<int[]> (){
      @Override
      public int compare(int[] a, int[] b) {
        return a[2] - b[2];
      }
    });
  }
}
