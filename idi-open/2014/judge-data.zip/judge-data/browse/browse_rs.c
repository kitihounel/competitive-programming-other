/* max flow to find assignment of sheeps to barns,
   binary search on max distance.
   solution by ruben spaans */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

int N,M,K;
int bx[500],by[500];   /* barn */
int sx[500],sy[500];   /* sheep */
double predist[500][500]; /* precalculate distances */

double dists[250000];
int dn;

/* max flow with edge cost 1, but arbitrary capacities. efficient memory
   usage: O(E) */
/* usage:
   - set MAXV,MAXE to guaranteed maximum values for the problem (MAXE
     includes back edges!)
   - set n to desired number of nodes, set ne=0
   - clear f[] to zero
   - define edges by using addedge(), preferably from left to right.
     back edges are added automatically.
   - radixsort()
   - inverseedges()
   - do a separate pass where caps are set in f[]. only set forward caps,
     back edges have cap 0.
   - finally, call maxflow()
*/

#define MAXE 520000
#define MAXV 1020
#define INF 1000000000

int from[MAXE],to[MAXE];  /* graph */
int gs[MAXV+1];           /* pointer to first node */
int f[MAXE];              /* flow */
int inv[MAXE];            /* index to reverse edge */
int n,ne;
int source,sheep,barn,sink;

int maxflow(int source,int sink) {
	int i,j,done,flow=0,done2,a,r,qe=0,k,l;
	static char t[MAXV];
	static int parent[MAXV],min[MAXV],q[MAXV];
	memset(t,0,n);
	memset(parent,-1,n*sizeof(int));
	memset(min,126,n*sizeof(int));
	do {
		done=1;
		t[source]=1;
		q[qe++]=source;
		do {
			done2=1;
			for(k=0;k<qe;k++) if(t[i=q[k]]) for(l=gs[i];l<gs[i+1];l++) {
				j=to[l];
				if(!t[j] && f[l]>0) {
					a=f[l];
					t[j]=1; parent[j]=l; done2=0;
					q[qe++]=j;
					if(min[i]<a) min[j]=min[i]; else min[j]=a;
					if(j==sink) { done=0; goto out; }
				}
			}
		} while(!done2);
		break;
	out:
		l=sink; r=min[sink];
		while(parent[l]>-1) {
			f[parent[l]]-=r;
			f[inv[parent[l]]]+=r;
			l=from[parent[l]];
		}
		flow+=r;
		while(qe) {
			j=q[--qe];
			t[j]=0; parent[j]=-1; min[j]=INF;
		}
	} while(!done);
	return flow;
}

void radixsort2() {
	static int newfrom[MAXE],newto[MAXE];
	int i,j;
	/* sort on to */
	memset(gs,0,sizeof(int)*(n+1));
	for(i=0;i<ne;i++) gs[to[i]]++;
	for(i=1;i<n;i++) gs[i]+=gs[i-1];
	for(i=ne-1;i>=0;i--) {
		j=--gs[to[i]];
		newto[j]=to[i];
		newfrom[j]=from[i];
	}
	/* (stable) sort on from */
	memset(gs,0,sizeof(int)*(n+1));
	for(i=0;i<ne;i++) gs[newfrom[i]]++;
	for(i=1;i<n;i++) gs[i]+=gs[i-1];
	gs[n]=ne;
	for(i=ne-1;i>=0;i--) {
		j=--gs[newfrom[i]];
		to[j]=newto[i];
		from[j]=newfrom[i];
	}
}

/* for each edge a->b, find index to b->a */
void inverseedges() {
	static int starts[MAXV+1];
	int i;
	memcpy(starts,gs,sizeof(int)*(n+1));
	for(i=0;i<ne;i++) inv[i]=starts[to[i]]++;
}

/* add both directions of an edge */
void addedge(int a,int b) {
	from[ne]=a; to[ne++]=b;
	from[ne]=b; to[ne++]=a;
}

int compd(const void *A,const void *B) {
	const double *a=A,*b=B;
	if(*a<*b) return -1;
	if(*a>*b) return 1;
	return 0;
}

double dist(int x1,int y1,int x2,int y2) {
	int dx=x1-x2,dy=y1-y2;
	return sqrt(dx*dx+dy*dy);
}

void creategraph() {
	int i,j;
	source=0;
	sheep=1;
	barn=sheep+N;
	sink=barn+M;
	n=2+N+M;
	ne=0;
	/* source to sheep */
	for(i=0;i<N;i++) addedge(source,sheep+i);
	/* sheep to barns */
	for(i=0;i<N;i++) for(j=0;j<M;j++) addedge(sheep+i,barn+j);
	/* barns to sink */
	for(i=0;i<M;i++) addedge(barn+i,sink);
	radixsort2();
	inverseedges();
}

void solve() {
	int lo=0,hi=dn,mid,i,a,b,r;
	/* binary search over indexes in distances array */
	while(lo<hi) {
		mid=lo+(hi-lo)/2;
		/* set capacities */
		memset(f,0,sizeof(f));
		for(i=0;i<ne;i++) {
			a=from[i];
			b=to[i];
			if(a==source) f[i]=1;
			else if(a>=sheep && a<sheep+N && b>=barn && b<barn+M) {
				f[i]=predist[a-sheep][b-barn]<=dists[mid];
			}
			else if(b==sink) f[i]=K;
		}
		/* flow! */
		r=maxflow(source,sink);
		if(r==N) hi=mid;
		else lo=mid+1;
	}
	printf("%.9f\n",dists[lo]);
}

int main() {
	int i,j,t;
    int T;
	scanf("%d", &T);
	for (t = 0; t < T; t++) {
    	scanf("%d %d %d",&N,&M,&K);
    	for(i=0;i<N;i++) scanf("%d %d",&sx[i],&sy[i]);
    	for(i=0;i<M;i++) scanf("%d %d",&bx[i],&by[i]);
    	/* precalculate distances */
    	for(dn=i=0;i<N;i++) for(j=0;j<M;j++)
    		dists[dn++]=predist[i][j]=dist(sx[i],sy[i],bx[j],by[j]);
    	qsort(dists,dn,sizeof(double),compd);
    	/* keep only unique ones */
    	for(i=j=1;i<dn;i++) if(dists[i-1]!=dists[i]) dists[j++]=dists[i];
    	dn=j;
    	creategraph();
    	solve();
	}
	return 0;
}
