#include <cstdio>
#include <set>
#include <cstring>
#include <cmath>
#include <queue>

using namespace std;

#define MAXN 505

int sheep[MAXN][2];
int barns[MAXN][2];
int dists[MAXN][MAXN];
int cap[MAXN + MAXN][MAXN + MAXN];
int pred[MAXN + MAXN];

int flow(int N, int M) {
  int res = 0;
  for (int i = 0; i < N; ++i) {
    memset(pred, -1, sizeof(pred));
    if (cap[N+M+1][i] > 0) {
      queue<int> q;
      q.push(i);
      pred[i] = N+M+1;
      while (q.size()) {
        int c = q.front(); q.pop();
        if (c == N+M) break;
        if (pred[N+M] == -1 && cap[c][N+M] > 0) {
          pred[N+M] = c;
          q.push(N+M);
          break;
        }
        int start = c < N ? N : 0;
        int stop = c < N ? N+M : N;
        for (int j = start; j < stop; ++j) {
          if (pred[j] == -1 && cap[c][j] > 0) {
            pred[j] = c;
            q.push(j);
          }
        }
      }
      if (pred[N+M] == -1) return 0;
      int x = N+M;
      while (x <= N+M) {
        int next = pred[x];
        cap[next][x]--;
        cap[x][next]++;
        x = next;
      }
      res++;
    }
  }
  return res;
}

void solve() {
  int N, M, K; scanf("%d%d%d", &N, &M, &K);
  for (int i = 0; i < N; ++i) {
    scanf("%d%d", &sheep[i][0], &sheep[i][1]);
  }
  for (int i = 0; i < M; ++i) {
    scanf("%d%d", &barns[i][0], &barns[i][1]);
  }

  set<int> s;
  for (int i = 0; i < N; ++i) {
    for (int j = 0; j < M; ++j) {
      int dx = sheep[i][0] - barns[j][0];
      int dy = sheep[i][1] - barns[j][1];
      dists[i][j] = dx*dx + dy*dy;
      s.insert(dists[i][j]);
    }
  }
  vector<int> d(s.begin(), s.end());

  int l = 0, r = d.size()-1;
  while (l < r) {
    int med = (l + r) / 2;
    int m = d[med];
    memset(cap, 0, sizeof(cap));
    for (int i = 0; i < N; ++i) {
      cap[N+M+1][i] = 1;
      for (int j = 0; j < M; ++j) {
        if (dists[i][j] <= m) cap[i][N+j] = 1;
      }
    }
    for (int i = 0; i < M; ++i) {
      cap[N+i][N+M] = K;
    }
    if (flow(N, M) == N) {
      r = med;
    } else {
      l = med + 1;
    }
  }
  printf("%.8f\n", sqrt((double)d[l]));
}

int main() {
  int T; scanf("%d", &T);
  while(T--) solve();
}
