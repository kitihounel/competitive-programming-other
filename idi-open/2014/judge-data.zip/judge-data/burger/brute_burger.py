from sys import stdin
from itertools import chain, combinations

_in = map(int, stdin.read().split())[::-1]
I = _in.pop


def powerset(xs):
    return chain.from_iterable(combinations(xs, n) for n in range(len(xs)+1))


def solve_one():
    B, Nb, Nc, Nt, Ns = I(), I(), I(), I(), I()

    cheeses = range(Nc)
    toppings = range(Nt)
    sauces = range(Ns)

    num_opts = 0
    for burger_size in range(1, B+1):
        for bun in range(Nb):
            for cs in powerset(cheeses):
                for ts in powerset(toppings):
                    for sc in powerset(sauces):
                        price = burger_size
                        if len(cs) > 1:
                            price += len(cs) - 1
                        if len(ts) > 3:
                            price += len(ts) - 3
                        if len(sc) > 1:
                            price += len(sc) - 1

                        if price <= B:
                            num_opts += 1
    print num_opts


for t in range(I()):
    solve_one()
