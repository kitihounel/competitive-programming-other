import java.io.*;
import java.util.*;
import static java.lang.System.out;


class burger_ed {
    static Scanner sc = new Scanner(new BufferedInputStream(System.in));

    public static void main(String[] __) {
        build_nCr();

        for (int i = 0, T = sc.nextInt(); i < T; ++i)
            solveOne();
    }

    static void solveOne() {
        for (int i = 0; i < MAX; ++i)
            memo[0][i] = memo[1][i] = memo[2][i] = -1;

        int B = sc.nextInt(),
            N_b = sc.nextInt();

        optsAt = new int[] { sc.nextInt(), sc.nextInt(), sc.nextInt() };
        freeAt = new int[] { 1, 3, 1 };

        long res = 0;
        for (int ms = 1; ms <= B; ms++)
            res = (res + N_b * numOpts(0, B - ms)) % MOD;
        out.println(res);
    }

    static int MAX = 1003;
    static long MOD = 1000000007L;

    static long nCr[][] = new long[MAX][MAX];

    static int optsAt[];
    static int freeAt[];

    static long[][] memo = new long[3][MAX];

    static long numOpts(int at, int bLeft) {
        if (at == 3)
            return 1;

        if (memo[at][bLeft] != -1)
            return memo[at][bLeft];

        long res = 0;

        for (int i = 0; i <= freeAt[at]; ++i) {
            res += nCr[ optsAt[at] ][ i ] * numOpts(at+1, bLeft);
            res %= MOD;
        }

        for (int extra = 1; extra <= bLeft; ++extra) {
            res += nCr[ optsAt[at] ][ freeAt[at]+extra ] * numOpts(at+1, bLeft-extra);
            res %= MOD;
        }

        return memo[at][bLeft] = res;
    }

    static void build_nCr() {
        nCr[0][0] = 1;
        for(int i = 0; i < MAX; i++) {
            nCr[i][0] = nCr[i][i] = 1;
            for(int j = 1; j < i; j++)
                nCr[i][j] = (nCr[i-1][j-1] + nCr[i-1][j]) % MOD;
        }
    }
}
