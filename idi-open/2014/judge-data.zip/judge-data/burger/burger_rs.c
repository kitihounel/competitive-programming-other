#include <stdio.h>
#include <string.h>

#define MAX 1002
#define MOD 1000000007

typedef long long ll;

int pascal[MAX][MAX];

void genpascal() {
	int i,j;
	for(i=0;i<MAX;i++) {
		pascal[i][0]=pascal[i][i]=1;
		for(j=1;j<i;j++) {
			pascal[i][j]=pascal[i-1][j]+pascal[i-1][j-1];
			if(pascal[i][j]>=MOD) pascal[i][j]-=MOD;
		}
	}
}

int dp[4][MAX];

void solve() {
	int B,Nb,Nc,Nt,Ns,i,j,w,k,r;
	scanf("%d %d %d %d %d",&B,&Nb,&Nc,&Nt,&Ns);
	memset(dp,0,sizeof(dp));
	/* burger size, and bun: Nb ways to pick burger+bun of cost i */
	for(i=1;i<=B;i++) dp[0][i]=Nb;
	/* cheese */
	for(i=1;i<=B;i++) {
		dp[1][i]=(dp[1][i]+(ll)dp[0][i]*(Nc+1))%MOD;
		for(j=2,k=i+1;k<=B && j<=Nc;j++,k++)
			dp[1][k]=(dp[1][k]+(ll)dp[0][i]*pascal[Nc][j])%MOD;
	}
	/* toppings */
	w=(Nt+1+pascal[Nt][2]+pascal[Nt][3])%MOD;
	for(i=1;i<=B;i++) {
		dp[2][i]=(dp[2][i]+(ll)dp[1][i]*w)%MOD;
		for(j=4,k=i+1;k<=B && j<=Nt;j++,k++)
			dp[2][k]=(dp[2][k]+(ll)dp[1][i]*pascal[Nt][j])%MOD;
	}
	/* sauce */
	for(i=1;i<=B;i++) {
		dp[3][i]=(dp[3][i]+(ll)dp[2][i]*(Ns+1))%MOD;
		for(j=2,k=i+1;k<=B && j<=Ns;j++,k++)
			dp[3][k]=(dp[3][k]+(ll)dp[2][i]*pascal[Ns][j])%MOD;
	}
	for(r=0,i=1;i<=B;i++) {
		r+=dp[3][i];
		if(r>=MOD) r-=MOD;
	}
	printf("%d\n",r);
}

int main() {
	int T;
	genpascal();
	scanf("%d",&T);
	while(T--) solve();
	return 0;
}
