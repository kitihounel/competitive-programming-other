#include <iostream>
#include <cassert>
#include <cmath>
#include <cstring>


long long ncr[1005][1005];
long long dp[1005][4];

using namespace std;

int main() {
  long long MOD = 1000000007;
  memset(ncr, 0, sizeof(ncr));
  for (int i = 0; i < 1001; ++i) {
    for (int j = 1; j < i; ++j) {
      ncr[i][j] = (ncr[i-1][j-1] + ncr[i-1][j]) % MOD;
    }
    ncr[i][0] = ncr[i][i] = 1;
  }

  int TC; cin >> TC;
  while (TC--) {
    long long B, Nb, Nc, Nt, Ns; cin >> B >> Nb >> Nc >> Nt >> Ns;
    assert (1 <= B && B <= 1000);
    assert (1 <= Nb && Nb <= 1000);
    assert (1 <= Nc && Nc <= 1000);
    assert (3 <= Nt && Nt <= 1000);
    assert (1 <= Ns && Ns <= 1000);

    memset(dp, 0, sizeof(dp));
    for (int i = 0; i < B; ++i) {
      dp[i][0] = Nb;
    }

    // Cheeses
    // How many dollars did we already spend?
    for (int i = 0; i < B; ++i) {
      // Free cheese
      dp[i][1] = (dp[i][0] * (Nc + 1) + dp[i][1]) % MOD;
      
      // j is how many extra types of cheese we use
      for (int j = 1; i + j < B; ++j) {
        long long num = (dp[i][0] * ncr[Nc][j+1]) % MOD;
        dp[i+j][1] = (num + dp[i+j][1]) % MOD;
      }
    }

    // Toppings
    for (int i = 0; i < B; ++i) {
      // j is how many toppings we use
      for (int j = 0; i + j - 3 < B; ++j) {
        long long num = (dp[i][1] * ncr[Nt][j]) % MOD;
        int price = i + max(0, j-3);
        dp[price][2] = (num + dp[price][2]) % MOD;
      }
    }

    // Sauces
    // How many dollars did we already spend?
    for (int i = 0; i < B; ++i) {
      // No sauce
      dp[i][3] = (dp[i][3] + dp[i][2]) % MOD;
      
      // j is how many extra types of sauce we use
      for (int j = 0; i + j < B; ++j) {
        long long num = (dp[i][2] * ncr[Ns][j+1]) % MOD;
        dp[i+j][3] = (num + dp[i+j][3]) % MOD;
      }
    }

    long long result = 0;
    for (int i = 0; i < B; ++i) {
      result = (result + dp[i][3]) % MOD;
    }
    cout << result << endl;
  }
}
