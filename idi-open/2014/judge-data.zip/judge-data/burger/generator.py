import random

print 20

print 1, 1, 1, 3, 1
print 1000, 1000, 1000, 1000, 1000
print 1, 1000, 1000, 1000, 1000
print 1000, 1, 1, 3, 1

for i in xrange(16):
  print random.randint(1, 1000), random.randint(1, 1000), random.randint(1, 1000), random.randint(3, 1000), random.randint(1, 1000)
