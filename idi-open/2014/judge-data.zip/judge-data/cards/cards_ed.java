/*
 * General case:
 *  - You start with K out of N cards facing upwards in one heap.
 *  - Move K cards from this first heap to a second heap.
 *  - You now have 0 <= k <= K cards facing upwards in the second heap, and
 *    K-k cards facing up in the first.
 *  - Flip the K cards in the second heap. There are now K-k cards facing up
 *    in the second.
 *  - All good after K+K operations.
 *
 * Special case, N = K:
 *  - N even: move N/2 cards to a new heap for a total of N/2 operations
 *  - N odd:  move floor(N)/2 cards to a new heap, flip 1 card in the first
 *            heap, for a total of floor(N)/2 + 1 operations
 *
 * For optimality: In the general case, if K > N/2, "flip" K
 *
 * Proof of optimality: Beats me...
 */


class cards_ed {
    public static void main(String[] __) {
        java.util.Scanner sc = new java.util.Scanner(System.in);

        for (int t = 0, T = sc.nextInt(); t < T; ++t) {
            int N = sc.nextInt(),
                K = sc.nextInt();

            System.out.println(
                    N == K ? N/2 + N%2
                           : Math.min(K, N-K) + K
            );
        }
    }
}
