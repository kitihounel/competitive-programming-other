/* algorithm: observed pattern from brute force algorithm.
   solution by ruben spaans */

#include <stdio.h>

int main() {
	int T,N,K;
	scanf("%d",&T);
	while(T--) {
		scanf("%d %d",&N,&K);
		if(N==K) printf("%d\n",(N+1)/2);
		else if(K+K<=N) printf("%d\n",K+K);
		else printf("%d\n",N);
	}
	return 0;
}
