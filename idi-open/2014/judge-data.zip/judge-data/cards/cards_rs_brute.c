/* stupid brute force solution which gets infeasible at N over 30 */

#include <stdio.h>

typedef unsigned long long ull;

int bitcount(ull mask,int lo,int hi) {
	int r=0;
	for(;lo<hi;lo++) r+=(mask&(1ULL<<lo))>0;
	return r;
}

ull snoob(ull x) {
	ull s=x&-x, r=x+s, o=x^r;
	o=(o>>2)/s;
	return r|o;
}

#define INF 1000

void solve(int N,int K) {
	int move,flipl,flipr,left,right,curl,curr;
	int best=INF;
	ull mask,maskl,maskr;
	if(!K) {
		/* trivial, no need for bruteforce (it crashes anyway) */
		puts("0");
		return;
	}
	/* for each number of move and flip left and flip right */
	for(move=0;move+move<=N;move++) for(flipl=0;flipl<=move;flipl++) for(flipr=0;flipr<=N-move;flipr++) {
		mask=(1ULL<<K)-1;
		maskl=(1ULL<<flipl)-1;
		maskr=((1ULL<<flipr)-1)<<(N-flipr);
		left=bitcount(mask^maskl,0,move);
		right=bitcount(mask^maskr,move,N);
		if(left!=right) continue;
		mask=snoob(mask);
		while(mask<(1ULL<<N)) {
			curl=bitcount(mask^maskl,0,move);
			curr=bitcount(mask^maskr,move,N);
			if(curl!=curr) goto fail;
			mask=snoob(mask);
		}
		if(best>move+flipl+flipr) best=move+flipl+flipr;
	fail:;
	}
	if(best==INF) puts("-1");
	else printf("%d\n",best);
}

int main() {
	int N,K;
	for(N=1;;N++) for(K=0;K<=N;K++) printf("N=%2d K=%2d: ",N,K),solve(N,K);
	return 0;
}
