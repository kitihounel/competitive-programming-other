#include <iostream>

using namespace std;

void solve() {
  int N, K; cin >> N >> K;
  if (N == K) {
    cout << (N/2) + (N%2) << endl;
  } else if (K <= N/2) {
    cout << 2 * K << endl;
  } else {
    cout << N << endl;
  }
}

int main() {
  int TC; cin >> TC;
  while (TC--) solve();
}
