from random import randint

print 20
print 1000, 1000
print 999, 999
print 1000, 1
print 1000, 999

for i in xrange(16):
  N = randint(1, 1001)
  print N, randint(1, N+1)
