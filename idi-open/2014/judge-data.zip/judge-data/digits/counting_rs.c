#include <stdio.h>

typedef long long ll;

/* return number of zeroes, including leading zeroes, of all
   n-digit numbers */
ll count2(int n) {
	ll r=1;
	int i;
	if(n<1) return 0;
	for(i=1;i<n;i++) r*=10;
	return r*n;
}

/* return number of zeroes from 0 to n, inclusive */
ll solve(ll n) {
	ll it=99,r=9,m=1,ans=0;
	int z,i,l,j;
	char s[24];
	if(n<0) return 0;
	if(n<10) return 1;
	/* check if n is 9, 99, 999, 9999 etc */
	while(it<1000000000000000000LL) {
		if(it==n) return r*m+solve(n/10);
		it=it*10+9;
		r=r*10;
		m++;
	}
	sprintf(s,"%lld",n);
	for(l=18,it=1000000000000000000LL;it>0;it/=10,l--) if(n>=it) {
		for(i=z=0;s[i];i++) if(s[i]=='0') z++;
		for(m=1,j=0,i--;i;i--,j++,m*=10) if(s[i]>'0') {
			/* add contribution from zeroes in front of us with this digit=0 */
			ans+=m*(z+1);
			/* add contribution from zeroes at and behind us */
			ans+=count2(j)*(s[i]-'0');
			/* add contribution for leading zeroes with digits 1 to this-1 */
			ans+=z*m*(s[i]-'1');
		} else ans++,z--;
		if(s[0]>'1') ans+=count2(j)*(s[0]-'1');
		return ans+solve(it-1);
	}
	return 0;
}

int main() {
	ll a,b;
	while(scanf("%lld %lld",&a,&b)==2) printf("%lld\n",solve(b)-solve(a-1));
	return 0;
}
