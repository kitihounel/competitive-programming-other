/* brute force solution by ruben spaans */

#include <stdio.h>

int main() {
	int a,b,r,i,t;
	char s[22];
	scanf("%d", &t);
	while(t--){
		scanf("%d %d",&a,&b);
		r=0;
		while(a<=b) {
			sprintf(s,"%d",a);
			for(i=0;s[i];i++) r+=s[i]=='0';
			a++;
		}
		printf("%d\n",r);
	}
	return 0;
}
