#include <iostream>
#include <algorithm>
#include <sstream>

using namespace std;

int main(void) {
  int cases; cin >> cases;
  while (cases-->0) {
    int N,M; cin >> N >> M;
    int count=0;
    
    for (int i=N; i<=M; i++) {
      stringstream ss;
      ss << i << endl;
      string sss = ss.str();
      for (int k=0; k<sss.size(); k++) {
	if (sss[k] == '0') count++;
      }
    }
      cout << count << endl;
  }
}
