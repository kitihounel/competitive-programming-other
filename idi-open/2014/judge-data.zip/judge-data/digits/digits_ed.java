class digits_ed {
    public static void main(String[] __) {
        java.util.Scanner sc = new java.util.Scanner(System.in);

        int T = sc.nextInt();
        while (T --> 0) {
            final int N = sc.nextInt(),
                      M = sc.nextInt();

            int res = 0;
            for (int k = N; k <= M; ++k)
                for (char c : (""+k).toCharArray())
                    if (c == '0')
                        ++res;
            System.out.println(res);
        }
    }
}
