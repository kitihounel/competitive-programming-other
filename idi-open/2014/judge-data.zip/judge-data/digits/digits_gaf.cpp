#include <iostream>

using namespace std;

int numZero(int num){
	int tot = 0;
	do{
		if(num%10 == 0)
			++tot;
		num /= 10;
	}while(num > 0);

	return tot;
}

int main(){
	int T;
	cin >> T;
	while(T--){
		int N, M;
		cin >> N >> M;
		long long tot = 0;
		for(int i = N; i <=M; ++i){
			tot += numZero(i);
		}
		cout << tot << endl;
	}
}

