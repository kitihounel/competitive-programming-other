#include <stdio.h>
#include <string.h>


int main() {
  int T; scanf("%d", &T);
  while (T--) {
    int N, M; scanf("%d%d", &N, &M);
    int res = 0;
    long long res2 = 0;
    for (int i = N; i <= M; ++i) {
      char num[30];
      sprintf(num, "%d", i);
      for (int j = 0; j < strlen(num); ++j) {
        res += num[j] == '0';
      }
    }
    printf("%d\n", res);
  }
}
