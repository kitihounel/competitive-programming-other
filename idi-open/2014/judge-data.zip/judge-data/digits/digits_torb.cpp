#include <iostream>
#include <cassert>

using namespace std;

int main() {
  int T; cin >> T;
  while (T--) {
    int N, M; cin >> N >> M;
    assert (0 <= N && N <= M && M <= 1000000);
    int res = 0;
    long long res2 = 0;
    for (int i = N; i <= M; ++i) {
      int a = i;
      do {
        if (a % 10 == 0) {
          res++;
          res2++;
        }
        a /= 10;
      } while (a);
    }
    assert (res == res2);
    cout << res << endl;
  }
}
