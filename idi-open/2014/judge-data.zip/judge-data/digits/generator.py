import random
print 20

print 0, 0
print 0, 1000000
print 1000000, 1000000
print 1, 2
print 0, 110
for i in xrange(15):
  N = random.randint(0, 1000000)
  M = random.randint(0, 1000000)
  print min(N, M), max(N, M)

