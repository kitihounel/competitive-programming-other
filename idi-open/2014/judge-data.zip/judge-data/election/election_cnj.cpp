#include <iostream>
#include <algorithm>
#include <sstream>
#include <string>
#include <vector>
#include <cmath>

using namespace std;

int main(void) {
  int cases; cin >> cases;
  while (cases-->0) {
    int players; cin >> players;
    vector<string> name(players);
    vector<int> x(players);
    vector<int> y(players);
    vector<int> r(players);
    for (int p=0; p<players; p++) {
      cin >> name[p] >> x[p] >> y[p] >> r[p];
    }
    vector<int> allies(players);
    int max_allies=-1;
    int emperor_to_be=-1;
    for (int p=0; p<players; p++) {
      for (int pp=p+1; pp<players; pp++) {
	if (sqrt( pow((x[p]-x[pp]),2) + pow((y[p]-y[pp]),2)) < r[p]+r[pp]) {
	  allies[p]++;
	  allies[pp]++;
	}
      }
      if (allies[p] > max_allies) {
	max_allies=allies[p];
	emperor_to_be = p;
      }
    }

    for (int p=0; p<players; p++) {
      if (p!=emperor_to_be && allies[p] == max_allies) {
	emperor_to_be = -1;
	break;
      }
    }

    if (emperor_to_be == -1)
      cout << "TIE" << endl;
    else
      cout << name[emperor_to_be] << endl;
  }
}
