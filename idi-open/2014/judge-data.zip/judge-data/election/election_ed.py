from itertools import combinations

for t in range(input()):
    players = []
    for i in range(input()):
        xs = raw_input().split()
        players.append([xs[0], map(int, xs[1:]), 0])

    for p, q in combinations(players, 2):
        px, py, pr = p[1]
        qx, qy, qr = q[1]
        if (px-qx)**2 + (py-qy)**2 < (pr+qr)**2:
            p[2] += 1
            q[2] += 1

    players.sort(key=lambda p: -p[2])
    print 'TIE' if players[0][2] == players[1][2] else players[0][0]
