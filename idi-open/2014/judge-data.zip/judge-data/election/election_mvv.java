import java.util.Arrays;
import java.util.Scanner;

/**
 * Limitations for this task is very lenient, with N <= 100.
 * This is a simple O(n^2) algorithm  that checks the distances
 * between every pair of points, and counts them as overlapping if
 * the distance is smaller than the combined radii of the circles.
 */
public class election_mvv {

    static final Scanner sc = new Scanner(System.in);

    static int I() {return sc.nextInt();}
    static String T() {return sc.next();}

    public static void main(String[] args) {
        int T = I();

        while (T --> 0) {
            int N = I();
            String[] names = new String[N];
            int[] x = new int[N];
            int[] y = new int[N];
            int[] r = new int[N];

            for (int n = 0; n < N; n++) {
                names[n] = T();
                x[n] = I();
                y[n] = I();
                r[n] = I();
            }

            int[] matches = new int[N];
            Arrays.fill(matches, 0);
            for (int i = 0; i < N; i++) {
                for (int j = i+1; j < N; j++) {
                    int dx = Math.abs(x[i] - x[j]);
                    int dy = Math.abs(y[i] - y[j]);
                    int radii = r[i] + r[j];
                    if (dx*dx + dy*dy < radii*radii) {
                        matches[i]++;
                        matches[j]++;
                    }
                }
            }

            int max = -1;
            int maxi = -1;
            boolean tied = true;
            for (int i = 0; i < N; i++) {
                if (matches[i] > max) {
                    max = matches[i];
                    maxi = i;
                    tied = false;
                } else if (matches[i] == max) {
                    tied = true;
                }
            }

            if (tied) {
                System.out.println("TIE");
            } else {
                System.out.println(names[maxi]);
            }
        }
    }

}
