#include <stdio.h>

char navn[100][257];
int x[100],y[100],r[100];
int n;

int overlap(int ix,int iy) {
	int dx=x[ix]-x[iy],dy=y[ix]-y[iy],dr=r[ix]+r[iy];
	return dx*dx+dy*dy<=dr*dr;
}

void solve() {
	int bestix=-1,cnt=0,best=-1,i,j,cur;
	scanf("%d",&n);
	for(i=0;i<n;i++) scanf("%s %d %d %d",navn[i],&x[i],&y[i],&r[i]);
	for(i=0;i<n;i++) {
		for(cur=j=0;j<n;j++) if(overlap(i,j)) cur++;
		if(best==cur) cnt++;
		else if(best<cur) cnt=1,bestix=i,best=cur;
	}
	if(cnt>1) puts("TIE");
	else puts(navn[bestix]);
}

int main() {
	int T;
	scanf("%d",&T);
	while(T--) solve();
	return 0;
}
