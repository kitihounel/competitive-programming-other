#include <iostream>
#include <string>
#include <vector>
#include <cassert>
#include <cmath>

using namespace std;

void solve() {
  int N; cin >> N;
  assert (2 <= N && N <= 100);
  vector<string> names(N);
  vector<int> xs(N), ys(N), rs(N);
  for (int i = 0; i < N; ++i) {
    cin >> names[i] >> xs[i] >> ys[i] >> rs[i];
    assert (-100 <= xs[i] && xs[i] <= 100);
    assert (-100 <= ys[i] && ys[i] <= 100);
    for (int j = 0; j < names[i].size(); ++j) {
      if ('a' > names[i][j] || names[i][j] > 'z') {
        cout << names[i] << endl;
      }
      assert('a' <= names[i][j] && names[i][j] <= 'z');
    }
  }

  int best = -1;
  int bestidx = 0;
  int tie = 0;
  for (int i = 0; i < N; ++i) {
    int count = 0;
    for (int j = 0; j < N; ++j) {
      if (i == j) continue;
      int dist = (xs[i] - xs[j]) * (xs[i] - xs[j]);
      dist += (ys[i] - ys[j]) * (ys[i] - ys[j]);
      if (dist < (rs[i] + rs[j]) * (rs[i] + rs[j])) count++;
      //cout << dist << ' ' << (rs[i] - rs[j]) * (rs[i] - rs[j]) << endl;
      assert(abs(sqrt((double)dist) - sqrt((double)(rs[i] + rs[j]) * (rs[i] + rs[j]))) > 1e-6);
      // TODO: Add assert for touching circles
    }
    if (count == best) tie = 1;
    if (count > best) {
      tie = 0;
      best = count;
      bestidx = i;
    }
  }

  if (tie) cout << "TIE\n";
  else cout << names[bestidx] << endl;
}

int main() {
  int TC; cin >> TC;
  while (TC--) solve();
}
