from random import randint
from math import sqrt

print 20

print 3
print "torb", 0, 0, 1
print "edvard", 10, 10, 1
print "magne", -10, -10, 1

print 4
print "torb", 0, 0, 1
print "christian", 0, 0, 1
print "ruben", 10, 10, 1
print "torb", 10, 10, 1

print 3
print "torb", 0, 0, 10
print "geirarne", 3, 3, 1
print "christian", -1, -1, 1

print 2
print "torb", 10, 0, 10
print "charlie", -10, 1, 10

print 4
print "a", 0, 0, 4
print "b", 4, -3, 2
print "c", 4, 3, 2
print "d", 9, 0, 4

for i in xrange(15):
  N = randint(2, 100)
  print N
  Xs = []
  Ys = []
  Rs = []

  while len(Xs) < N:
    name = ""
    for k in xrange(randint(10, 255)):
      name += chr(ord('a') + randint(0, 25))
    X, Y, R = randint(-100, 100), randint(-100, 100), randint(1, 10)
    ok = True
    for j in xrange(len(Xs)):
      dist = ((Xs[j] - X) ** 2 + (Ys[j] - Y) ** 2)
      rad = (Rs[j] + R) ** 2
      if abs(sqrt(dist) - sqrt(rad)) < 1e-6:
        ok = False
    if not ok:
      continue
    Xs.append(X)
    Ys.append(Y)
    Rs.append(R)
    print name, X, Y, R
