#include <iostream>
#include <cstring>
#include <queue>
#include <vector>
#include <cassert>

using namespace std;

int preds[10005][10005];
int Rs[10005];
int inedges[10005];
int salaries[10005];
int seena[10005];
int seenb[10005];

void solve() {
  memset(preds, -1, sizeof(preds));
  memset(Rs, 0, sizeof(Rs));
  memset(inedges, 0, sizeof(inedges));
  memset(salaries, 0, sizeof(salaries));

  int N, C; cin >> N >> C;
  int CEO = -1;

  vector<int> adj_lists[10005];

  for (int i = 0; i < N; ++i) {
    cin >> salaries[i] >> Rs[i];
    inedges[i] = Rs[i];
    if (Rs[i] == 0) {
      assert (CEO == -1);
      CEO = i;
    }
    for (int j = 0; j < Rs[i]; ++j) {
      cin >> preds[i][j];
      adj_lists[preds[i][j]].push_back(i);
    }
  }

  vector<int> dom_tree[10005];
  vector<int> parent(10005, -1);
  vector<int> cost(10005, 0);
  queue<int> q;
  q.push(CEO);
  while(!q.empty()) {
    int c = q.front(); q.pop();
    for (int i = 0; i < adj_lists[c].size(); ++i) {
      int n = adj_lists[c][i];
      inedges[n]--;
      if (inedges[n] == 0) {
        q.push(n);
      }
    }
    if (c == CEO) continue;
    
    
    int p = preds[c][0];
    for (int i = 1; i < Rs[c]; ++i) {
      int n = preds[c][i];
      int a = p, b = n;
      memset(seena, 0, sizeof(seena));
      memset(seenb, 0, sizeof(seenb));
      seena[a] = 1;
      seenb[b] = 1;
      while (!seena[b] && !seenb[a]) {
        if (b != CEO) b = parent[b];
        if (a != CEO) a = parent[a];
        seena[a] = 1;
        seenb[b] = 1;
      }
      if (seena[b]) p = b;
      else p = a;
    }
    dom_tree[p].push_back(c);
    parent[c] = p;
    while (p != -1) {
      cost[p] += salaries[c];
      p = parent[p];
    }
  }

  int best = -1;
  int bestidx = -1;

  for (int i = 0; i < N; ++i) {
    int c = cost[i] + salaries[i];
    if (c >= C && (c <= best || best == -1)) {
      best = c;
      bestidx = i;
    }
  }

  cout << bestidx << endl;

}

int main() {
  int TC; cin >> TC;
  while (TC--) solve();
  return 0;
}
