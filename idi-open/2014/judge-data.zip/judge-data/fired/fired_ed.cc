/*
 * insight/ideas:
 *
 * - graph is a DAG. (reverse) topologically sort it so that id(a) > id(b)
 *   if b reports to a.
 *
 * - let reportsTo be an array of bitsets, with reportsTo[a] equal to (guess)
 *
 * - for toFire in 0..N-1:
 *      let employed = bitset with all N bits set  (everyone is still on)
 *
 *      for current in [reverse topological order]:
 *          compute intersection(reportsTo[current], employed)
 *
 *          if current equals toFire
 *          or current is not ceo and the intersection is empty:
 *              remove current from employed
 *
 *
 * complexity: O(N**3), low constant factor ;-)
 */


#include <bitset>
#include <cassert>
#include <cstdio>
#include <deque>
#include <string>
#include <vector>


using namespace std;

int I() { int n; scanf("%d", &n); return n; }

const int MaxN = 200;

bool SPECIAL_outputAllSums = false;
bool SPECIAL_outputCut = false;

void solveOne() {
    int N = I(), C = I();
    assert(N >= 1 && N <= 200);

    vector<int> salary(N, 0);
    vector<bitset<MaxN>> reportsTo(N, bitset<MaxN>());
    vector<int> numEdgesIn(N, 0);

    int salary_sum = 0;

    for (int i = 0; i < N; ++i) {
        salary[i] = I();
        assert(1 <= salary[i] && salary[i] <= 100000);
        salary_sum += salary[i];

        int R_i = I();
        assert(0 <= R_i && R_i < N);
        for (int j = 0; j < R_i; ++j) {
            int r = I();
            reportsTo[i][r] = true;
            numEdgesIn[r]++;
        }
    }

    assert(C >= 1 && C <= salary_sum);

    deque<int> Q;
    for (int i = 0; i < N; ++i) if (numEdgesIn[i] == 0) Q.push_back(i);

    deque<int> order;
    while (!Q.empty()) {
        int u = Q.front(); Q.pop_front();
        order.push_front(u);

        for (int v = 0; v < N; ++v) if (reportsTo[u][v])
            if ((--numEdgesIn[v]) == 0)
                Q.push_back(v);
    }

    int bestGain = 1 << 29,
        bestToFire = -1;
    bitset<MaxN> bestCut;


    for (int toFire = 0; toFire < N; ++toFire) {
        bitset<MaxN> employed; employed.flip();
        int gain = 0;

        for (int i : order) {
            bool shouldFire =
                (i == toFire) ||
                (reportsTo[i].any() && (reportsTo[i] & employed).none());

            if (shouldFire) {
                employed[i] = false;
                gain += salary[i];
            }
        }

        if (gain >= C && gain <= bestGain) {
            bestGain = gain;
            bestToFire = toFire;
            bestCut = employed;
            bestCut.flip();
        }

        if (SPECIAL_outputAllSums)
            printf("%d\n", gain);
    }

    if (SPECIAL_outputCut) {
      for (int i = 0; i < N; ++i)
        if (bestCut[i])
          printf("%d\n", i);
      return;
    }

    if (!SPECIAL_outputAllSums)
        printf("%d\n", bestToFire);
}

int main(int argc, char** argv) {
    if (argc == 2) {
      if (string(argv[1]) == "--find-possible-sums")
        SPECIAL_outputAllSums = true;
      else if (string(argv[1]) == "--find-cut")
        SPECIAL_outputCut = true;

      solveOne();
      return 0;
    }

    for (int t = 0, T = I(); t < T; ++t)
        solveOne();
    return 0;
}
