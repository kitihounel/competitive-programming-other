// not 95% sure about this, but seems to work...


import java.io.*;
import java.util.*;
import static java.lang.System.out;


class fired_ed {
    static BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
    static StringTokenizer st = new StringTokenizer("");
    static String T() throws Exception {
        while (!st.hasMoreTokens()) {
            st = new StringTokenizer(stdin.readLine());
        }
        return st.nextToken();
    }
    static int I() throws Exception { return Integer.parseInt(T()); }

    public static void main(String[] args) throws Exception {
        if (args.length == 1 && args[0].equals("--find-possible-sums")) {
            SPECIAL_outputAllSums = true;
            solveOne();
            return;
        }

        for (int i = 0, T = I(); i < T; ++i)
            solveOne();
    }

    static boolean SPECIAL_outputAllSums = false;

    static long[] salary;
    static long[] numSupervisors;
    static ArrayList<List<Integer>> subordinates;
    static List<Integer> lostSupervisorLog = new ArrayList<Integer>();

    static long toFire = -1; // debug
    static Set<Integer> fired;

    static void solveOne() throws Exception {
        int N = I(),
            C = I();

        salary = new long[N];
        numSupervisors = new long[N];
        subordinates = new ArrayList<List<Integer>>();
        for (int i = 0; i < N; ++i)
            subordinates.add(new ArrayList<Integer>());

        for (int i = 0; i < N; ++i) {
            salary[i] = I();
            for (int j = 0, R_i = I(); j < R_i; ++j) {
                int supervisor = I();
                subordinates.get(supervisor).add(i);
                numSupervisors[i]++;
            }
        }

        long bestV = 1234567891234L;
        long bestToFire = -1;

        for (int i = 0; i < N; ++i) {
            toFire = i;                       // debug

            fired = new HashSet<Integer>();
            lostSupervisorLog.clear();

            long v = cutFrom(i);
            if (v >= C && v <= bestV) {
                bestV = v;
                bestToFire = i;
            }

            for (int sub : lostSupervisorLog)
                numSupervisors[sub]++;

            if (SPECIAL_outputAllSums)
                out.println(v);
        }

        if (!SPECIAL_outputAllSums)
            out.println(bestToFire);
    }

    static long cutFrom(int emp) {
        assert emp == toFire || numSupervisors[emp] == 0; // debug
        assert numSupervisors[emp] >= 0;                  // debug
        assert !fired.contains(emp);                      // debug

        fired.add(emp);

        for (int sub : subordinates.get(emp)) {
            numSupervisors[sub]--;
            lostSupervisorLog.add(sub);
        }

        long res = salary[emp];
        for (int sub : subordinates.get(emp))
            if (numSupervisors[sub] == 0 && !fired.contains(sub))
                res += cutFrom(sub);
        return res;
    }
}
