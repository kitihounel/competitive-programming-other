from sys import stdin

_in = map(int, stdin.read().split())[::-1]
I = _in.pop

def solve_one():
    N, C = I(), I()

    salary = []
    reports_to = []
    for i in range(N):
        salary.append(I())
        reports_to.append([I() for r in range(I())])

    memo = {}
    def criticals(u):
        """
        Persons *required* to stay onboard for u to stay onboard.
        Eg. persons on every "chain of command" from u to the CEO.
        """
        if not u in memo:
            if not reports_to[u]:
                crits = 0
            else:
                crits = 2**N - 1
                for v in reports_to[u]:
                    crits &= criticals(v)
            crits |= 1 << u
            memo[u] = crits
        return memo[u]

    best_u, best_c = -1, 1E42
    for u in range(N):
        c = sum(salary[v] for v in range(N) if criticals(v) & (1 << u))
        if c >= C and c < best_c:
            best_u, best_c = u, c

    print best_u

for t in range(I()):
    solve_one()
