/* fire each person and do bfs from CEO in reverse graph to find employees
   to keep.
   O(VE) solution by ruben spaans */

#include <stdio.h>
#include <string.h>

#define MAXV 1001
#define MAXE (MAXV*MAXV)

typedef long long ll;

int n,ne,C;
int salary[MAXV];

int from[MAXE],to[MAXE];
int gs[MAXV+1];

/* subroutine: sort from[],to[] on increasing from[] and update gs[] */
void countingsort() {
	static int newto[MAXE];
	int i,j;
	for(i=0;i<=n;i++) gs[i]=0;
	for(i=0;i<ne;i++) gs[from[i]]++;
	for(i=1;i<n;i++) gs[i]+=gs[i-1];
	gs[n]=ne;
	for(i=0;i<ne;i++) {
		j=--gs[from[i]];
		newto[j]=to[i];
	}
	for(i=0;i<ne;i++) to[i]=newto[i];
	for(i=0;i<n;i++) for(j=gs[i];j<gs[i+1];j++) from[j]=i;
}

int q[MAXV],qs,qe;
char vis[MAXV];

void solve() {
	ll res,best,tot=0;
	int i,j,m,a,ceo=-1,cur,next,bestix;
	scanf("%d %d",&n,&C);
	ne=0;
	for(i=0;i<n;i++) {
		scanf("%d %d",&salary[i],&m);
		tot+=salary[i];
		if(!m) ceo=i;
		while(m--) {
			/* create reverse edge from employee a to employee i */
			scanf("%d",&a);
			from[ne]=a;
			to[ne++]=i;
		}
	}
	countingsort();
	/* try all firings */
	memset(vis,0,sizeof(vis));
	best=tot;
	bestix=ceo;
	for(i=0;i<n;i++) if(i!=ceo) {
		qs=qe=0;
		q[qe++]=ceo;
		vis[ceo]=1;
		res=tot-salary[ceo];
		while(qs<qe) {
			cur=q[qs++];
			for(j=gs[cur];j<gs[cur+1];j++) {
				next=to[j];
				if(next==i || vis[next]) continue;
				vis[next]=1;
				q[qe++]=next;
				res-=salary[next];
			}
		}
		for(j=0;j<qe;j++) vis[q[j]]=0;
		if(res>=C && best>=res) best=res,bestix=i;
	}
	if(best<C) puts("illegal input or bug in solution");
	else printf("%d\n",bestix);
}

int main() {
	int T;
	scanf("%d",&T);
	while(T--) solve();
	return 0;
}
