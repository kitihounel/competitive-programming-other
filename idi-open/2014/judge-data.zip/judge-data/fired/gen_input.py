"""
test case generator for "fired"

uses alternative mode of ed's solution to find all
possible cut sums, before choosing a value for C
"""


import os
import sys
from random import randint, sample, choice, shuffle, seed, random
from subprocess import check_call


seed(0x42)


def shell(line):
    return check_call(line, shell=True)


def gen_rooted_connected_dag(size, select_adjs):
    res = []
    for i in range(size):
        if i == 0:
            adjs = []
        else:
            adjs = select_adjs(i)
            assert adjs != [], 'must be connected!'
            for x in adjs:
                assert 0 <= x < i
        res.append(adjs)
    return res


def permute_graph(adjs):
    n = len(adjs)

    perm = range(n)
    shuffle(perm)

    temp = [[i, adjs[i]] for i in range(n)]
    for t in temp:
        t[0] = perm[t[0]]
        t[1] = [perm[j] for j in t[1]]
    temp.sort(lambda a, b: cmp(a[0], b[0]))

    return [t[1] for t in temp]


def gen_salaries(num, min_salary, max_salary):
    return [randint(min_salary, max_salary) for i in range(num)]


def find_all_possible_sums(adjs, salaries):
    special_input = format_case(adjs, salaries, 1)

    if not os.path.exists('fired_ed'):
        shell('g++ -std=c++11 -O3 fired_ed.cc -o fired_ed')

    with open('special_in', 'w') as f:
        f.write(special_input)
    shell('./fired_ed --find-possible-sums < special_in > special_out')
    with open('special_out') as f:
        all_sums = map(int, f.read().split())
    shell('rm special_in special_out')
    return all_sums


def find_correct_cut(adjs, salaries, C):
    special_input = format_case(adjs, salaries, C)
    with open('special_in', 'w') as f:
        f.write(special_input)
    shell('./fired_ed --find-cut < special_in > special_out')
    with open('special_out') as f:
        cut = map(int, f.read().split())
    shell('rm special_in special_out')
    return cut


def choose_C(adjs, salaries):
    all_sums = sorted(find_all_possible_sums(adjs, salaries))

    if len(all_sums) == 1:
        C = randint(0, all_sums[0])
    else:
        if random() > .5 and len(all_sums) > 10:
            all_sums = all_sums[-3:]

        two_rand_sums = sample(all_sums, 2)
        C = randint(min(two_rand_sums), max(two_rand_sums))
    return C


def format_case(adjs, salaries, C):
    assert len(adjs) == len(salaries)

    n = len(adjs)
    accum = []
    accum.append('%d %d\n' % (n, C,))

    for i_adjs, i_sal in zip(adjs, salaries):
        accum.append('%d %d' % (i_sal, len(i_adjs)))
        for a in i_adjs:
            accum.append(' %d' % a)
        accum.append('\n')

    return ''.join(accum)


def debug_assert_is_connected_dag(adjs):
    N = len(adjs)

    num_incoming = [0 for i in adjs]
    for i in range(N):
        for j in range(N):
            if j in adjs[i]:
                num_incoming[j] += 1

    Q = set(i for i in range(N) if num_incoming[i] == 0)

    L = []
    while Q:
        v = Q.pop()
        L.append(v)

        for w in adjs[v]:
            num_incoming[w] -= 1
            if num_incoming[w] == 0:
                Q.add(w)

    if set(range(N)) != set(L):
        raise Exception('Not a DAG!')


def debug_draw_case((adjs, salaries, C,), file_name):
    from pydot import Dot, Node, Edge

    n = len(adjs)

    graph = Dot(graph_type='digraph')

    cut = find_correct_cut(adjs, salaries, C)

    nodes = [Node('i=%d S=%d' % (i, s),
                  style='filled',
                  fillcolor='green' if i in cut else 'white')
             for i, s in enumerate(salaries)]
    for x in nodes:
        graph.add_node(x)

    for i, i_adjs, i_sal in zip(range(n), adjs, salaries):
        for j, a in enumerate(i_adjs):
            graph.add_edge(Edge(nodes[i], nodes[a]))

    graph.write_png(file_name)


def main():
    shell('rm -f fired_ed')

    MAX_N = 200
    MIN_SALARY, MAX_SALARY = 1, 100000

    def gen_case(select_adjs, select_n=lambda: randint(1, MAX_N)):
        n = select_n()

        nonpermuted_adjs = gen_rooted_connected_dag(n, select_adjs)
        adjs = permute_graph(nonpermuted_adjs)
        debug_assert_is_connected_dag(adjs)

        salaries = gen_salaries(n, min_salary=MIN_SALARY, max_salary=MAX_SALARY)
        C = choose_C(adjs, salaries)

        return adjs, salaries, C

    def gen_string_of_1_case():
        return gen_case(lambda i: [i-1])

    def gen_three_layer_case():
        # 0         = ceo
        # 1..n/2    = first layer, connected to ceo
        # n/2+1,n   = second layer, connected to all in first

        n = choice([4, 8, 16, 32, 64])+1
        def select_adjs(i):
            if 1 <= i <= n//2:
                return [0]
            else:
                assert n//2+1 <= i <= n
                return range(1, n//2+1)
        return gen_case(select_adjs, lambda: n)

    def gen_fully_connected_case():
        return gen_case(lambda i: range(i))

    def gen_all_random_case():
        edge_prob = choice([0.01, 0.2])
        def select_adjs(i):
            num_adjs = randint(1, max(1, int(edge_prob*i)))
            return sample(range(i), num_adjs)
        return gen_case(select_adjs)

    def repeat(n, f, *nkw):
        return [f(*nkw) for i in range(n)]

    minimal_case = (
        [[]],
        [1],
        1,
    )

    minimal_select_highest_id_case = (
        [[], [0], [0]],
        [1,    2,   2],
        2,
    )

    cases = (
        [minimal_case]                       +
        [minimal_select_highest_id_case]     +
        repeat(10, gen_string_of_1_case)     +
        repeat(10, gen_three_layer_case)     +
        repeat(10, gen_fully_connected_case) +
        repeat(68, gen_all_random_case)
    )

    num_cases = len(cases)
    with open('fired.in', 'w') as of:
        of.write('%d\n' % num_cases)
        for case_num, case in enumerate(cases, start=1):
            of.write(format_case(*case))

            num_nodes = len(case[0])
            num_edges = sum(len(ia) for ia in case[0])
            edges_per_node = num_edges / float(num_nodes)
            cut_percent = (100 *
                    len(find_correct_cut(*case)) / float(num_nodes))

            print '%-3d/%-3d  N=%-8d C=%-8d #e=%-8d #e/n=%-8.2f #cut=%.2f%%' % (
                      case_num, num_cases, num_nodes, case[2], num_edges,
                      edges_per_node, cut_percent)

            if sys.argv[1:] == ['--draw-cases'] and num_nodes <= 80:
                debug_draw_case(case, 'case%04d.png' % case_num)


if __name__ == '__main__':
    main()
