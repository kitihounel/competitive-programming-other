from random import randint, shuffle

def check(lines, N):
  nm = [[False] * N for i in xrange(N)]
  for line in lines:
    for a in line:
      for b in line:
        nm[a][b] = True
  for k in xrange(N):
    for i in xrange(N):
      for j in xrange(N):
        if not nm[i][j]:
          nm[i][j] = nm[i][k] and nm[k][j]

  for l in nm:
    for x in l:
      if not x:
        return False

  return True

print 20

# Many switches

print 1, 100, 2, 1, 100

res = "100"
dist = 0
for i in xrange(100):
  res += " %d %d" %(i+1, dist)
  dist += 1 if i % 2 == 0 else 10
print res
res = "100"
dist = 0
for i in xrange(100):
  res += " %d %d" %(i+1, dist)
  dist += 1 if i % 2 == 1 else 10
print res

# Single line, going backwards
print 1, 100, 1, 100, 1

res = "100"
dist = 0
for i in xrange(100):
  res += " %d %d" %(i+1, dist)
  dist += 1 if i % 2 == 0 else 10
print res

cases = 2
while cases < 20:
  S = randint(1, 100)
  N = randint(2, 100)
  M = randint(1, 10)
  A = randint(1, N-1)
  B = randint(A+1, N)
  lines = [[] for l in xrange(M)]
  
  #Add all stations to some lines
  for i in xrange(N):
    num = randint(1, (M+1)/2)
    toadd = range(M)
    shuffle(toadd)
    for j in xrange(num):
      lines[toadd[j]].append(i)
  
  if not check(lines, N):
    continue
  cases += 1

  print S, N, M, A, B
  for line in lines:
    res = str(len(line))
    dist = 0
    for station in line:
      res += " %d %d" % (station+1, dist)
      dist += randint(1, 10)
    print res
