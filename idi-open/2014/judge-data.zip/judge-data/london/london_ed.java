import java.io.*;
import java.util.*;
import static java.lang.System.out;


public class london_ed {
  static BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
  static StringTokenizer st = new StringTokenizer("");
  static String T() throws Exception {
    while (!st.hasMoreTokens()) {
      st = new StringTokenizer(stdin.readLine());
    }
    return st.nextToken();
  }
  static int I() throws Exception { return Integer.parseInt(T()); }

  public static void main(String[] __) throws Exception {
    for (int t = 0, T = I(); t < T; ++t)
      solveOne();
  }

  static void solveOne() throws Exception {
    final int S = I(), N = I(), M = I(), A = I(), B = I();

    // indexing:
    //   id(line, station) = line*NUM_STATIONS + station
    //
    //   reserve two extra nodes for "master" start and end points
    //   reserve zero as a dummy node (input is 1-indexed)
    final int Max = N*M+3,
              start = Max-2,
              end = Max-1;

    ArrayList<List<Edge>> edges = new ArrayList<List<Edge>>();
    for (int i = 0; i < Max; ++i)
      edges.add(new ArrayList<Edge>());

    // add crossedges for all stations
    for (int m1 = 0; m1 < M; ++m1) for (int m2 = 0; m2 < M; ++m2)
      for (int n = 1; n <= N; ++n)
        edges.get(m1*N + n).add(new Edge(m2*N + n, S));

    // add zero-cost edge from "master" start node to all lines starting at A
    // ...and reverse idea for end node
    for (int m = 0; m < M; ++m) {
      edges.get(start).add(new Edge(m*N + A, 0));
      edges.get(m*N + B).add(new Edge(end, 0));
    }

    // add normal edges on each line
    for (int m = 0; m < M; ++m) {
      int X = I();
      int[] ids = new int[X],
            dists = new int[X];
      for (int j = 0; j < X; ++j) { ids[j] = m*N + I(); dists[j] = I(); }

      for (int k = 1; k < X; ++k) {
        edges.get(ids[k-1]).add(new Edge(ids[k],   dists[k]-dists[k-1]));
        edges.get(ids[k  ]).add(new Edge(ids[k-1], dists[k]-dists[k-1]));
      }
    }

    out.println(
        dijkstra(edges, start).get(end)
    );
  }

  static ArrayList<Long> dijkstra(ArrayList<List<Edge>> edges, int start) {
    int n = edges.size();

    final ArrayList<Long> dist = new ArrayList<Long>();
    for (int i = 0; i < n; ++i)
      dist.add(INF);
    dist.set(start, 0L);

    final TreeSet<Integer> Q = new TreeSet<Integer>(new Comparator<Integer>() {
        @Override
        public int compare(Integer a, Integer b) {
          long da = dist.get(a),
               db = dist.get(b);
          return da == db ? a - b :
                 da >  db ? 1
                          : -1;
        }
    });
    Q.add(start);

    while (!Q.isEmpty()) {
      int u = Q.pollFirst();
      for (Edge e : edges.get(u)) {
        long alt = dist.get(u) + e.cost;
        if (alt < dist.get(e.to)) {
          Q.remove(e.to);
          dist.set(e.to, alt);
          Q.add(e.to);
        }
      }
    }

    return dist;
  }

  static class Edge {
    final int to; final long cost;
    Edge(int to, long cost) { this.to = to; this.cost = cost; }
  }

  static final long INF = Long.MAX_VALUE/3;
}
