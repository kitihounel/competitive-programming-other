/* solution without node splitting.
   O(n^2) by ruben spaans */

#include <stdio.h>
#include <string.h>

#define MAXV 101
#define INF 1000000001

int g[MAXV][MAXV];
int s,n,m,a,b;

void addedge(int a,int b,int c) {
	if(g[a][b]>c) g[a][b]=c;
}

/* no need for efficient dijkstra, graph is always complete */
int dijkstra(int start,int goal) {
	static int dist[MAXV];
	static char vis[MAXV];
	int i,u,v,z;
	memset(dist,62,sizeof(int)*n);
	memset(vis,0,n);
	dist[start]=0;
	while(1) {
		for(u=-1,z=INF,i=0;i<n;i++) if(!vis[i] && z>dist[i]) u=i,z=dist[i];
		if(u==goal) return z;
		vis[u]=1;
		for(v=0;v<n;v++) if(dist[v]>dist[u]+g[u][v]) dist[v]=dist[u]+g[u][v];
	}
}

void solve() {
	int i,j,x;
	static int sn[MAXV],st[MAXV];
	scanf("%d %d %d %d %d",&s,&n,&m,&a,&b);
	for(i=0;i<n;i++) for(j=0;j<n;j++) g[i][j]=i==j?0:INF;
	/* construction: O(M*X^2) */
	while(m--) {
		scanf("%d",&x);
		for(i=0;i<x;i++) scanf("%d %d",&sn[i],&st[i]);
		for(i=0;i<x-1;i++) for(j=i+1;j<x;j++) {
			addedge(sn[i]-1,sn[j]-1,st[j]-st[i]+s);
			addedge(sn[j]-1,sn[i]-1,st[j]-st[i]+s);
		}
	}
	printf("%d\n",dijkstra(a-1,b-1)-s);
}

int main() {
	int T;
	scanf("%d",&T);
	while(T--) solve();
	return 0;
}
