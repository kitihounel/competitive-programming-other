#include <iostream>
#include <cstring>
#include <queue>
#include <cmath>

const int MAXN = 100;
const int MAXM = 10;

using namespace std;

int nm[MAXN * MAXM + 5][MAXN * MAXM + 5];
int dist[MAXN * MAXM + 5];
int used[MAXN * MAXM + 5];
int lines[MAXN + 5][MAXM + 5];
int line[MAXN + 5][2];
int linecounts[MAXM + 5];

typedef pair<int, int> ii;

int solve() {
  memset(nm, -1, sizeof(nm));
  memset(lines, 0, sizeof(lines));

  int S, N, M, A, B; cin >> S >> N >> M >> A >> B;
  A--; B--;
  for (int i = 0; i < M; ++i) {
    int X; cin >> X;
    linecounts[i] = X;
    for (int j = 0; j < X; ++j) {
      int station, time; cin >> station >> time;
      station--;
      line[j][0] = station;
      line[j][1] = time;
      lines[station][i] = 1;
      for (int k = 0; k < j; ++k) {
        int d = line[j][1] - line[k][1];
        int stationA = M * line[j][0] + i, stationB = M * line[k][0] + i;
        nm[stationA][stationB] = nm[stationB][stationA] = d;
      }
    }
  }
  for (int i = 0; i < N; ++i) {
    for (int j = 0; j < M; ++j) {
      for (int k = 0; k < j; ++k) {
        if (lines[i][j] && lines[i][k]) {
          int stationA = M * i + j, stationB = M * i + k;
          nm[stationA][stationB] = nm[stationB][stationA] = S;
        }
      }
    }
  }
  int best = 1000000;
  for (int startline = 0; startline < M; ++startline) {
    if (!lines[A][startline]) continue;
    memset(dist, -1, sizeof(dist));
    memset(used, 0, sizeof(used));
    priority_queue<ii> q;
    q.push(ii(0, A * M + startline));
    while  (q.size()) {
      ii current = q.top(); q.pop();
      int d = -current.first, n = current.second;
      if (used[n]) continue;
      used[n] = 1;
      if (n >= B * M && n < (B + 1) * M) {
        best = min(best, d);
        break;
      }
      for (int i = 0; i < N*M; ++i) {
        if (nm[n][i] != -1 && !used[i]) {
          if (dist[i] == -1 || dist[i] > d + nm[n][i]) {
            dist[i] = d + nm[n][i];
            q.push(ii(-dist[i], i));
          }
        }
      }
    }
  }
  return best;
}

int main() {
  int TC; cin >> TC;
  while(TC--) {
    cout << solve() << endl;
  }
}
