from random import randint

print 30

for ua in [1, 4]:
  for ud in [1, 4]:
    for X in [1, 500]:
      for Y in [1, 500]:
        print ua, ud, X, Y

for i in xrange(14):
  print randint(1, 4), randint(1, 4), randint(1, 500), randint(1, 500)
