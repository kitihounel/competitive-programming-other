/*
 * core insight:
 *  there's no need to look at the *exact* dice rolled by each player at each
 *  step -- the only important thing is seeing how many times the attacking
 *  player has a greater or equal die in the comparision.
 *
 */

import java.io.*;
import java.util.*;
import static java.lang.Math.*;


class risk_ed {
  static BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
  static StringTokenizer st = new StringTokenizer("");
  static String T() throws Exception {
    while (!st.hasMoreTokens())
      st = new StringTokenizer(stdin.readLine());
    return st.nextToken();
  }
  static int I() throws Exception { return Integer.parseInt(T()); }

  public static void main(String[] args) throws Exception {
    calc_p_dice();

    for (int i = 0, T = I(); i < T; ++i)
      solve_one();
  }

  static void solve_one() throws Exception {
    for (double[] xs : memo) Arrays.fill(xs, -1);

    d_a = I(); d_d = I();
    int X = I(), Y = I();

    for (int num_extra = 0; ; ++num_extra)
      if (p_win(X+num_extra, Y) >= 0.75) {
        System.out.println(num_extra);
        return;
      }
  }

  static int d_a, d_d;
  static double[][] memo = new double[4042][4042];

  static double p_win(int u_a, int u_b) {
    if (u_a == 0) return 0.0;
    if (u_b == 0) return 1.0;

    if (memo[u_a][u_b] == -1) {
      int r_a = min(u_a, d_a),
          r_b = min(u_b, d_d),
          r   = min(r_a, r_b);

      double res = 0;
      for (int lose_a = 0, lose_b = r; lose_a <= r; ++lose_a, --lose_b)
        res += p_dice(r_a, r_b, lose_a, lose_b) * p_win(u_a-lose_a, u_b-lose_b);
      memo[u_a][u_b] = res;
    }

    return memo[u_a][u_b];
  }

  static double p_dice(int r_a, int r_b, int lose_a, int lose_b) {
    return n_cases[r_a][r_b][lose_a][lose_b] / (double) v_cases[r_a][r_b];
  }

  static int[][][][] n_cases = new int[5][5][5][5];
  static int[][] v_cases = new int[5][5];

  static void calc_p_dice() {
    List<Integer[]> perms = new ArrayList<>();
    for (int i = 1; i <= 4; ++i)
      gen_perms(new Integer[i], 0, perms);

    for (Integer[] as : perms) for (Integer[] bs : perms) {
      int r_a = as.length, r_b = bs.length;
      int lose_a = 0, lose_b = 0;

      for (int i = 0; i < min(r_a, r_b); ++i)
        if (as[i] > bs[i]) lose_b++;
        else lose_a++;

      ++n_cases[r_a][r_b][lose_a][lose_b];
      ++v_cases[r_a][r_b];
    }
  }

  static void gen_perms(Integer[] n, int idx, List<Integer[]> res) {
    if (idx == n.length) {
      Integer[] nn = n.clone();
      Arrays.sort(nn);
      for (int i = 0; i < nn.length/2; i++) {
        int t = nn[i];
        nn[i] = nn[nn.length-i-1];
        nn[nn.length-i-1] = t;
      }
      res.add(nn);
    } else {
      for (int i = 1; i <= 6; i++) {
        n[idx] = i;
        gen_perms(n, idx+1, res);
      }
    }
  }
}
