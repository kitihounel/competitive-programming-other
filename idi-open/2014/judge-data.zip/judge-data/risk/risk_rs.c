#include <stdio.h>
#include <string.h>

/* set MAXX high enough for worst case 1 4 1 500 */
#define MAXX 4000
#define MAX 501

int da,db,x,y;

double dq[5][5][5][5];
double dp[MAXX][MAX];

void copy(int *to,int *from,int n) {
	while(n--) *(to++)=*(from++);
}

void sort(int *a,int n) {
	int i,j,t;
	for(i=0;i<n-1;i++) for(j=0;j<n-1;j++) if(a[j]<a[j+1]) t=a[j],a[j]=a[j+1],a[j+1]=t;
}

void pre() {
	double p;
	int u,v,i,j,t1,t2;
	int v1[4],v2[4],s1[4],s2[4];
	for(i=0;i<5;i++) for(j=0;j<5;j++) for(u=0;u<5;u++) for(v=0;v<5;v++) dq[i][j][u][v]=0;
	for(u=1;u<=da;u++) for(v=1;v<=db;v++) {
		for(p=1,i=0;i<u+v;i++) p/=6;
		for(i=0;i<u;i++) v1[i]=0;
		while(1) {
			for(i=0;i<v;i++) v2[i]=0;
			while(1) {
				copy(s1,v1,u); sort(s1,u);
				copy(s2,v2,v); sort(s2,v);
				for(t1=t2=i=0;i<u && i<v;i++) if(s1[i]>s2[i]) t2++; else t1++;
				dq[u][v][t1][t2]+=p;
				i=0;
			inner:
				v2[i]++;
				if(v2[i]==6) {
					v2[i++]=0;
					if(i==v) break;
					goto inner;
				}
			}
			i=0;
		outer:
			v1[i]++;
			if(v1[i]==6) {
				v1[i++]=0;
				if(i==u) break;
				goto outer;
			}
		}
	}
}

double btr(int ua,int ub) {
	double r;
	int i,j,u,v;
	if(!ua) return 0.;
	if(!ub) return 1.;
	if(dp[ua][ub]>=0) return dp[ua][ub];
	r=0;
	u=da; if(u>ua) u=ua;
	v=db; if(v>ub) v=ub;
	for(i=0;i<=da;i++) for(j=0;j<=db;j++) if(dq[u][v][i][j]) r+=dq[u][v][i][j]*btr(ua-i,ub-j);
	return dp[ua][ub]=r;
}

void solve() {
	int i,j;
	scanf("%d %d %d %d",&da,&db,&x,&y);
	pre();
	for(i=0;i<MAXX;i++) for(j=0;j<MAX;j++) dp[i][j]=-1;
	for(i=x;i<MAXX && btr(i,y)<0.75;i++);
	printf("%d\n",i-x);
}

int main() {
	int T;
	scanf("%d",&T);
	while(T--) solve();
	return 0;
}
