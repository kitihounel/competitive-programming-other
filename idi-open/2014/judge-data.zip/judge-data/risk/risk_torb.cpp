#include <iostream>
#include <cassert>
#include <cstring>
#include <algorithm>

double loseA[4][4][5];

double dp[1005][10];
int As[4];
int Bs[4];

using namespace std;

void go(int numA, int numB, int A, int B) {
  if (numA < A) {
    for (int i = 1; i <= 6; ++i) {
      As[numA] = i;
      go(numA + 1, numB, A, B);
    }
  } else if (numB < B) {
    for (int i = 1; i <= 6; ++i) {
      Bs[numB] = i;
      go(numA, numB + 1, A, B);
    }
  } else {
    int Acpy[4], Bcpy[4];
    for (int i = 0; i < A; ++i) {
      Acpy[i] = As[i];
    }
    for (int i = 0; i < B; ++i) {
      Bcpy[i] = Bs[i];
    }
    sort(Acpy, Acpy+A);
    sort(Bcpy, Bcpy+B);
    int lost = 0;
    for (int i = 1; i <= min(A, B); ++i) {
      lost += (Acpy[A-i] <= Bcpy[B-i]);
    }
    
    loseA[A-1][B-1][lost] += 1;
  }
}


int main() {
  int TC; cin >> TC;
  memset(loseA, 0, sizeof(loseA));

  for (int A = 1; A <= 4; ++A) {
    for (int B = 1; B <= 4; ++B) {
      go(0, 0, A, B);
      double sum = 0;
      for (int i = 0; i < 5; ++i) {
        sum += loseA[A-1][B-1][i];
      }
      for (int i = 0; i < 5; ++i) {
        loseA[A-1][B-1][i] /= sum;
      }
    }
  }

  while(TC--) {
    int Da, Dd, X, Y; cin >> Da >> Dd >> X >> Y;
    assert(1 <= Da && Da <= 4);
    assert(1 <= Dd && Dd <= 4);
    assert(1 <= X && X <= 500);
    assert(1 <= Y && Y <= 500);
    Da--; Dd--;
    memset(dp, 0, sizeof(dp));
    dp[0][0] = loseA[0][0][0];
    for (int i = 1; i < Y; ++i) {
      dp[i][0] = dp[i-1][0] * loseA[0][min(i, Dd)][0];
    }
    int x;
    for (x = 1; ; ++x) {
      for (int y = 0; y < Y; ++y) {
        int dx = min(x, Da);
        int dy = min(y, Dd);
        int b = min(dx, dy) + 1;
        dp[y][x%10] = 0;
        for (int i = 0; i <= b; ++i) {
          int ny = y - (b - i);
          int nx = x - i;
          if (nx < 0) {
            continue;
          }
          if (ny < 0) {
            dp[y][x%10] += loseA[dx][dy][i];
          } else {
            dp[y][x%10] += loseA[dx][dy][i] * dp[ny][(nx + 10) % 10];
          }
        }
      }
      if (dp[Y-1][x%10] >= 0.75) break;
    }
    double EPS = 1e-6;
    assert(dp[Y-1][x%10] - 0.75 > EPS);
    assert(0.75 - dp[Y-1][(x+9)%10] > EPS);
    cout << max(0, x-X+1) << endl;
  }
  return 0;
}
