
from random import randint, choice
from string import ascii_lowercase

def name():
    return ''.join(
        [choice(ascii_lowercase)] +
        [choice(ascii_lowercase + '  ') for _ in xrange(randint(1,20))] +
        [choice(ascii_lowercase)]
    )

def unique_names(n):
    names = set()

    while len(names) < n:
        names.add(name())
    return list(names)

def printcase(A, B, C, D):
    systems = unique_names(A+B+C)
    damages = [choice(systems) for _ in xrange(D)]

    print A, B, C, D
    print '\n'.join(systems)
    print '\n'.join(damages)
    

cases = 100
print cases

# Single system
for _ in xrange(3):
    printcase(randint(1,100), 0, 0, randint(1, 100))
    printcase(0, randint(1,100), 0, randint(1, 100))
    printcase(0, 0, randint(1,100), randint(1, 100))

    cases -= 3


# Edge: checking that power drains correctly
for _ in xrange(3):
    A, B, C, D = 0, 0, 2, 20
    systems = unique_names(C)
    damages = [systems[0]]*5 + [systems[1]]*15

    print A, B, C, D
    print '\n'.join(systems)
    print '\n'.join(damages)

    cases -= 1

# Max/min
printcase(100, 100, 100, 100)
printcase(0, 0, 0, 0)
cases -= 2

# Random
while cases > 0:
    A = B = C = 0
    while (A+B+C == 0):
        A = randint(0,100)
        B = randint(0,100)
        C = randint(0,100)
        
    printcase(A, B, C, D)
    cases -= 1
