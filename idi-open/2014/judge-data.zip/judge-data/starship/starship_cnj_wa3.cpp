#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <algorithm>

using namespace std;

int main(void) {
	const string ABANDON = "ABANDON SHIP. REPEAT. ALL HANDS ABANDON SHIP.";
	
	int cases;
	cin >> cases;
	while (cases-->0) {
	  int A,B,C,D;
	  cin >> A >> B >> C >> D;
	  cin.ignore();

	  int extra_power=20;
	  
	  vector<string> recalibrate;
	  map<string,bool> inverted;
	  map<string,int> divert;
	  
	  for (int i=0; i<A; i++) { // systems that need to be recalibrated
	    string thing; getline(cin, thing);
	    recalibrate.push_back(thing);
	  }
	  
	  for (int i=0; i<B; i++) { // systems that need to be reinverted
	    string thing; getline(cin, thing);
	    inverted[thing] = true;
	  }
	  
	  
	  for (int i=0; i<C; i++) { // systems that need to be diverted power to
	    string thing; getline(cin, thing);
	    divert[thing] = 100;
	    
	  }
	  
	  bool have_extra_power = true;
	  bool abandoned = false;
	  for (int i=0; i<D; i++) { // damages
	    string damaged; getline(cin, damaged);

	    if (abandoned) continue;
	    
	    if (find(recalibrate.begin(), recalibrate.end(), damaged) != recalibrate.end()) {
	      cout << "recalibrate " << damaged << endl;
	    }
	    
	    else if (inverted.find(damaged) != inverted.end()) {
	      if (inverted[damaged]) {
			cout << "invert " << damaged << endl;
			inverted[damaged] = false;
	      }
	      else {
			cout << "re-invert " << damaged << endl;
			
	      }
	      
	    }
	    
	    else if (divert.find(damaged) != divert.end()) {
	      if (extra_power >= 10) {
		extra_power -= 10;
		cout << "divert all power to " << damaged << endl;
	      }
	      else {
		divert[damaged] -= 10;
		if (divert[damaged] <= 10) {
		  cout << ABANDON << endl;
		  abandoned=true;
		}
		else {
		  cout << "divert all power to " << damaged << endl;
		}
	      }
	    }
	  }
	}
}
