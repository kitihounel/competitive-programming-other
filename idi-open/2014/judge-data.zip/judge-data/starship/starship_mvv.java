import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class starship_mvv {
    static Scanner sc = new Scanner(System.in);
    static int I() {return sc.nextInt();}
    static String L() {return sc.nextLine().trim();}

    public static void main(String[] args) {
        int cases = I();
        for (int CASE=0; CASE<cases; CASE++) {
            int[] n_category = new int[] {I(), I(), I()};
            int D = I();
            boolean abandoned = false;
            
            Map<String, Integer> categories = new HashMap<>();
            Map<String, Integer> states = new HashMap<>();
            
            sc.nextLine();
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < n_category[i]; j++) {
                    String system = L();
                    categories.put(system, i+1);
                    states.put(system, 0);
                }
            }
            
            int extra_power = 2;
            while (D --> 0) {
                String system = L();
                if (abandoned) continue;
                int category = categories.get(system);
                int state = states.get(system);
                switch (category) {
                case 1:
                    System.out.printf("recalibrate %s\n", system);
                    break;
                case 2:
                    if (state == 0) {
                        System.out.printf("invert %s\n", system);
                    } else {
                        System.out.printf("re-invert %s\n", system);
                    }
                    states.put(system, state == 0 ? 1 : 0);
                    break;
                case 3:
                    if (extra_power > 0) {
                        extra_power--;
                    } else {
                        state++;
                        states.put(system, state);
                    }
                    
                    if (state >= 9) {
                        System.out.println(
                            "ABANDON SHIP. REPEAT. ALL HANDS ABANDON SHIP."
                        );
                        abandoned = true;
                    } else {
                        System.out.printf("divert all power to %s\n", system, state);
                    }
                    break;
                }
            }
        }
    }
}