import sys

def unhappy(a, b, c, d, prefs):
  if prefs[a][c] < prefs[a][b] and prefs[c][a] < prefs[c][d]:
    return True
  if prefs[a][d] < prefs[a][b] and prefs[d][a] < prefs[d][c]:
    return True
  if prefs[b][c] < prefs[b][a] and prefs[c][b] < prefs[c][d]:
    return True
  if prefs[b][d] < prefs[b][a] and prefs[d][b] < prefs[d][c]:
    return True
  return False

def cool(config, prefs):
  N = len(config)
  if N % 2 == 1:
    return False 
  for i in xrange(N/2):
    a = config[2 * i]
    b = config[2 * i + 1]
    for j in xrange(i+1, N/2):
      c = config[2 * j]
      d = config[2 * j + 1]
      if unhappy(a, b, c, d, prefs):
        return False
  return True

def check(prefs, out, correct):
  if correct == "NO SOLUTION":
    return out == "NO SOLUTION"
  elif out == "NO SOLUTION":
    return False
  config = [int(x) for pair in out.split() for x in pair.split(":")]
  return cool(config, prefs)

with file(sys.argv[1], 'r') as input_file:
  with file(sys.argv[2], 'r') as output_file:
    with file(sys.argv[3], 'r') as correct_file:
      T = int(input_file.readline())
      for tc in xrange(1, T+1):
        N = int(input_file.readline())
        ranking = [[int(x) for x in input_file.readline().split()] for i in xrange(N)]
        prefs = [{} for i in xrange(N+1)]
        for i in xrange(N):
          for j, num in enumerate(ranking[i]):
            prefs[i+1][num] = j

        output_line = output_file.readline().strip()
        correct_line = correct_file.readline().strip()

        if not check(prefs, output_line, correct_line):
          print "Error in line %d: correct: %s, output: %s, prefs: %s" % (tc, correct_line, output_line, prefs)
