from random import shuffle, randint

print 1000


for i in xrange(1000):
  N = randint(2, 9)
  print N
  prefs = [filter(lambda x: x != i, range(1, N+1)) for i in xrange(1, N+1)]
  for j in xrange(N):
    shuffle(prefs[j])
    s = ""
    for k, num in enumerate(prefs[j]):
      if k != 0:
        s += " "
      s += str(prefs[j][k])
    print s
