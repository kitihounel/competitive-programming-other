from sys import stdin
from itertools import permutations

def printconfig(config):
  result = ""
  for i in xrange(len(config)/2):
    if i > 0:
      result += " "
    result += str(config[i*2]) + ":" + str(config[i*2 + 1])
  print result

def unhappy(a, b, c, d, prefs):
  if prefs[a][c] < prefs[a][b] and prefs[c][a] < prefs[c][d]:
    return True
  if prefs[a][d] < prefs[a][b] and prefs[d][a] < prefs[d][c]:
    return True
  if prefs[b][c] < prefs[b][a] and prefs[c][b] < prefs[c][d]:
    return True
  if prefs[b][d] < prefs[b][a] and prefs[d][b] < prefs[d][c]:
    return True
  return False

def cool(config, prefs):
  N = len(config)
  if N % 2 == 1:
    return False 
  for i in xrange(N/2):
    a = config[2 * i]
    b = config[2 * i + 1]
    for j in xrange(i+1, N/2):
      c = config[2 * j]
      d = config[2 * j + 1]
      if unhappy(a, b, c, d, prefs):
        return False
  return True

TC = int(stdin.readline())

for tc in xrange(TC):
  N = int(stdin.readline())
  ranking = [[int(x) for x in stdin.readline().split()] for i in xrange(N)]
  prefs = [{} for i in xrange(N+1)]
  for i in xrange(N):
    for j, num in enumerate(ranking[i]):
      prefs[i+1][num] = j

  people = range(1, N+1)
  found = False
  for config in permutations(people):
    if cool(config, prefs):
      printconfig(config)
      found = True
      break

  if not found:
    print "NO SOLUTION"

