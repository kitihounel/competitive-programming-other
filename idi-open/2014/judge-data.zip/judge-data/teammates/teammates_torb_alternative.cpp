#include <iostream>
#include <cassert>
#include <vector>
#include <cstring>
#include <sstream>

using namespace std;

#define MAX 1005

int preference[MAX][MAX];
int ranking[MAX][MAX];
int leftmost[MAX];
int second[MAX];
int rightmost[MAX];
int proposed_to[MAX];

void debug_print(int N) {
  cout << "#######\n";
  for (int i = 0; i < N; ++i) {
    for (int j = leftmost[i]; j <= rightmost[i]; ++j) {
      if (ranking[preference[i][j]][i] <= rightmost[preference[i][j]]) cout << preference[i][j] << ' '; 
    }
    cout << endl;
  }
  cout << "#######\n";
}

string solve() {
  memset(preference, 0, sizeof(preference));
  memset(ranking, 0, sizeof(ranking));
  memset(leftmost, 0, sizeof(leftmost));
  memset(rightmost, 0, sizeof(rightmost));
  memset(second, 0, sizeof(second));
  memset(proposed_to, 0, sizeof(proposed_to));
  int N; scanf("%d", &N);
  assert(N >= 2 && N <= 100);
  for (int i = 0; i < N; ++i) {
    for (int j = 0; j < N-1; ++j) {
      scanf("%d", &preference[i][j]);
      preference[i][j]--;
      ranking[i][preference[i][j]] = j;
    }
    preference[i][N-1] = i;
    ranking[i][i] = N-1;
    rightmost[i] = N-1;
    second[i] = 1;
  }
  if (N % 2) {
    return "NO SOLUTION";
  }
  int proposer;
  int next_choice;
  int current;
  for (int i = 0; i < N; ++i) {
    proposer = i;
    do {
      next_choice = preference[proposer][leftmost[proposer]];
      current = preference[next_choice][rightmost[next_choice]];
      while (ranking[next_choice][proposer] > ranking[next_choice][current]) {
        leftmost[proposer]++;
        next_choice = preference[proposer][leftmost[proposer]];
        current = preference[next_choice][rightmost[next_choice]];
      }
      rightmost[next_choice] = ranking[next_choice][proposer];
      proposer = current;
    } while (proposed_to[next_choice]);
    proposed_to[next_choice] = 1;
  }
  if (proposer != next_choice) {
    return "NO SOLUTION";
  }

  // Add last step of phase 1 reduction
  for (int i = 0; i < N; ++i) {
    second[i] = leftmost[i] + 1;
  }

  // Implement phase 2

  while (true) {
    int next = -1;
    for (int i = 0; i < N; ++i) {
      if (leftmost[i] != rightmost[i]) {
        next = i;
        break;
      }
    }
    if (next == -1) {
      break;
    }
    //seek cycle
    vector<int> cycle;
    vector<int> used(N, 0);
    int first = next, last;
    do {
      cycle.push_back(next);
      used[next] = 1;
      int next_choice = preference[next][second[next]];
      while (ranking[next_choice][next] > rightmost[next_choice]) {
        second[next]++;
        next_choice = preference[next][second[next]];
      }
      next = preference[next_choice][rightmost[next_choice]];
    } while (!used[next]);

    first = cycle.size() - 1;
    for (int i = cycle.size() - 2; i >= 0; --i) {

      if (preference[cycle[i]][leftmost[cycle[i]]] == preference[cycle[first]][second[cycle[first]]]) {
        first = i;
        break;
      }
    }
    
    for (int i = first; i < cycle.size(); ++i) {
      int person = cycle[i];
      leftmost[person] = second[person];
      second[person]++;
      int next_choice = preference[person][leftmost[person]];
      rightmost[next_choice] = ranking[next_choice][person];
    }

    for (int i = first; i < cycle.size(); ++i) {
      if (leftmost[cycle[i]] > rightmost[cycle[i]]) return "NO SOLUTION";
    }
  }

  stringstream ret;
  for (int i = 0; i < N; ++i) {
    int next = preference[i][leftmost[i]];
    if (next > i) {
      if (i > 0) {
        ret << " ";
      }
      ret << next + 1 << ":" << i + 1;
    }
  }
  return ret.str();
}

int main() {
  int TC; cin >> TC;
  while (TC--) {
    cout << solve() << endl;
  }
}

